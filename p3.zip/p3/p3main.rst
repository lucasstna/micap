                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 3.6.0 #9615 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module p3main
                                      6 	.optsdcc -mmcs51 --model-small
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _le_ADC0_PARM_2
                                     12 	.globl _esc_RAM_SPI_PARM_2
                                     13 	.globl _main
                                     14 	.globl _Init_Device
                                     15 	.globl _Interrupts_Init
                                     16 	.globl _Oscillator_Init
                                     17 	.globl _Port_IO_Init
                                     18 	.globl _Voltage_Reference_Init
                                     19 	.globl _DAC_Init
                                     20 	.globl _ADC_Init
                                     21 	.globl _SPI_Init
                                     22 	.globl _UART_Init
                                     23 	.globl _PCA_Init
                                     24 	.globl _Timer_Init
                                     25 	.globl _Reset_Sources_Init
                                     26 	.globl _printf_fast_f
                                     27 	.globl _CANTEST
                                     28 	.globl _CANCCE
                                     29 	.globl _CANDAR
                                     30 	.globl _CANIF
                                     31 	.globl _CANEIE
                                     32 	.globl _CANSIE
                                     33 	.globl _CANIE
                                     34 	.globl _CANINIT
                                     35 	.globl _SPIEN
                                     36 	.globl _TXBMT
                                     37 	.globl _NSSMD0
                                     38 	.globl _NSSMD1
                                     39 	.globl _RXOVRN
                                     40 	.globl _MODF
                                     41 	.globl _WCOL
                                     42 	.globl _SPIF
                                     43 	.globl _AD2WINT
                                     44 	.globl _AD2CM0
                                     45 	.globl _AD2CM1
                                     46 	.globl _AD2CM2
                                     47 	.globl _AD2BUSY
                                     48 	.globl _AD2INT
                                     49 	.globl _AD2TM
                                     50 	.globl _AD2EN
                                     51 	.globl _AD0LJST
                                     52 	.globl _AD0WINT
                                     53 	.globl _AD0CM0
                                     54 	.globl _AD0CM1
                                     55 	.globl _AD0BUSY
                                     56 	.globl _AD0INT
                                     57 	.globl _AD0TM
                                     58 	.globl _AD0EN
                                     59 	.globl _CCF0
                                     60 	.globl _CCF1
                                     61 	.globl _CCF2
                                     62 	.globl _CCF3
                                     63 	.globl _CCF4
                                     64 	.globl _CCF5
                                     65 	.globl _CR
                                     66 	.globl _CF
                                     67 	.globl _P
                                     68 	.globl _F1
                                     69 	.globl _OV
                                     70 	.globl _RS0
                                     71 	.globl _RS1
                                     72 	.globl _F0
                                     73 	.globl _AC
                                     74 	.globl _CY
                                     75 	.globl _CPRL4
                                     76 	.globl _CT4
                                     77 	.globl _TR4
                                     78 	.globl _EXEN4
                                     79 	.globl _EXF4
                                     80 	.globl _TF4
                                     81 	.globl _CPRL3
                                     82 	.globl _CT3
                                     83 	.globl _TR3
                                     84 	.globl _EXEN3
                                     85 	.globl _EXF3
                                     86 	.globl _TF3
                                     87 	.globl _CPRL2
                                     88 	.globl _CT2
                                     89 	.globl _TR2
                                     90 	.globl _EXEN2
                                     91 	.globl _EXF2
                                     92 	.globl _TF2
                                     93 	.globl _LEC0
                                     94 	.globl _LEC1
                                     95 	.globl _LEC2
                                     96 	.globl _TXOK
                                     97 	.globl _RXOK
                                     98 	.globl _EPASS
                                     99 	.globl _EWARN
                                    100 	.globl _BOFF
                                    101 	.globl _SMBTOE
                                    102 	.globl _SMBFTE
                                    103 	.globl _AA
                                    104 	.globl _SI
                                    105 	.globl _STO
                                    106 	.globl _STA
                                    107 	.globl _ENSMB
                                    108 	.globl _BUSY
                                    109 	.globl _PX0
                                    110 	.globl _PT0
                                    111 	.globl _PX1
                                    112 	.globl _PT1
                                    113 	.globl _PS0
                                    114 	.globl _PT2
                                    115 	.globl _EX0
                                    116 	.globl _ET0
                                    117 	.globl _EX1
                                    118 	.globl _ET1
                                    119 	.globl _ES0
                                    120 	.globl _ET2
                                    121 	.globl _EA
                                    122 	.globl _RI1
                                    123 	.globl _TI1
                                    124 	.globl _RB81
                                    125 	.globl _TB81
                                    126 	.globl _REN1
                                    127 	.globl _MCE1
                                    128 	.globl _S1MODE
                                    129 	.globl _RI0
                                    130 	.globl _TI0
                                    131 	.globl _RB80
                                    132 	.globl _TB80
                                    133 	.globl _REN0
                                    134 	.globl _SM20
                                    135 	.globl _SM10
                                    136 	.globl _SM00
                                    137 	.globl _CP2HYN0
                                    138 	.globl _CP2HYN1
                                    139 	.globl _CP2HYP0
                                    140 	.globl _CP2HYP1
                                    141 	.globl _CP2FIF
                                    142 	.globl _CP2RIF
                                    143 	.globl _CP2OUT
                                    144 	.globl _CP2EN
                                    145 	.globl _CP1HYN0
                                    146 	.globl _CP1HYN1
                                    147 	.globl _CP1HYP0
                                    148 	.globl _CP1HYP1
                                    149 	.globl _CP1FIF
                                    150 	.globl _CP1RIF
                                    151 	.globl _CP1OUT
                                    152 	.globl _CP1EN
                                    153 	.globl _CP0HYN0
                                    154 	.globl _CP0HYN1
                                    155 	.globl _CP0HYP0
                                    156 	.globl _CP0HYP1
                                    157 	.globl _CP0FIF
                                    158 	.globl _CP0RIF
                                    159 	.globl _CP0OUT
                                    160 	.globl _CP0EN
                                    161 	.globl _IT0
                                    162 	.globl _IE0
                                    163 	.globl _IT1
                                    164 	.globl _IE1
                                    165 	.globl _TR0
                                    166 	.globl _TF0
                                    167 	.globl _TR1
                                    168 	.globl _TF1
                                    169 	.globl _P7_7
                                    170 	.globl _P7_6
                                    171 	.globl _P7_5
                                    172 	.globl _P7_4
                                    173 	.globl _P7_3
                                    174 	.globl _P7_2
                                    175 	.globl _P7_1
                                    176 	.globl _P7_0
                                    177 	.globl _P6_7
                                    178 	.globl _P6_6
                                    179 	.globl _P6_5
                                    180 	.globl _P6_4
                                    181 	.globl _P6_3
                                    182 	.globl _P6_2
                                    183 	.globl _P6_1
                                    184 	.globl _P6_0
                                    185 	.globl _P5_7
                                    186 	.globl _P5_6
                                    187 	.globl _P5_5
                                    188 	.globl _P5_4
                                    189 	.globl _P5_3
                                    190 	.globl _P5_2
                                    191 	.globl _P5_1
                                    192 	.globl _P5_0
                                    193 	.globl _P4_7
                                    194 	.globl _P4_6
                                    195 	.globl _P4_5
                                    196 	.globl _P4_4
                                    197 	.globl _P4_3
                                    198 	.globl _P4_2
                                    199 	.globl _P4_1
                                    200 	.globl _P4_0
                                    201 	.globl _P3_7
                                    202 	.globl _P3_6
                                    203 	.globl _P3_5
                                    204 	.globl _P3_4
                                    205 	.globl _P3_3
                                    206 	.globl _P3_2
                                    207 	.globl _P3_1
                                    208 	.globl _P3_0
                                    209 	.globl _P2_7
                                    210 	.globl _P2_6
                                    211 	.globl _P2_5
                                    212 	.globl _P2_4
                                    213 	.globl _P2_3
                                    214 	.globl _P2_2
                                    215 	.globl _P2_1
                                    216 	.globl _P2_0
                                    217 	.globl _P1_7
                                    218 	.globl _P1_6
                                    219 	.globl _P1_5
                                    220 	.globl _P1_4
                                    221 	.globl _P1_3
                                    222 	.globl _P1_2
                                    223 	.globl _P1_1
                                    224 	.globl _P1_0
                                    225 	.globl _P0_7
                                    226 	.globl _P0_6
                                    227 	.globl _P0_5
                                    228 	.globl _P0_4
                                    229 	.globl _P0_3
                                    230 	.globl _P0_2
                                    231 	.globl _P0_1
                                    232 	.globl _P0_0
                                    233 	.globl _DP
                                    234 	.globl _ADC0
                                    235 	.globl _ADC0LT
                                    236 	.globl _ADC0GT
                                    237 	.globl _TMR4
                                    238 	.globl _TMR3
                                    239 	.globl _TMR2
                                    240 	.globl _RCAP4
                                    241 	.globl _RCAP3
                                    242 	.globl _RCAP2
                                    243 	.globl _DAC1
                                    244 	.globl _DAC0
                                    245 	.globl _CAN0DAT
                                    246 	.globl _PCA0CP5
                                    247 	.globl _PCA0CP4
                                    248 	.globl _PCA0CP3
                                    249 	.globl _PCA0CP2
                                    250 	.globl _PCA0CP1
                                    251 	.globl _PCA0CP0
                                    252 	.globl _PCA0
                                    253 	.globl _WDTCN
                                    254 	.globl _PCA0CPH1
                                    255 	.globl _PCA0CPL1
                                    256 	.globl _PCA0CPH0
                                    257 	.globl _PCA0CPL0
                                    258 	.globl _PCA0H
                                    259 	.globl _PCA0L
                                    260 	.globl _P7
                                    261 	.globl _CAN0CN
                                    262 	.globl _SPI0CN
                                    263 	.globl _EIP2
                                    264 	.globl _EIP1
                                    265 	.globl _B
                                    266 	.globl _RSTSRC
                                    267 	.globl _PCA0CPH4
                                    268 	.globl _PCA0CPL4
                                    269 	.globl _PCA0CPH3
                                    270 	.globl _PCA0CPL3
                                    271 	.globl _PCA0CPH2
                                    272 	.globl _PCA0CPL2
                                    273 	.globl _P6
                                    274 	.globl _ADC2CN
                                    275 	.globl _ADC0CN
                                    276 	.globl _EIE2
                                    277 	.globl _EIE1
                                    278 	.globl _XBR3
                                    279 	.globl _XBR2
                                    280 	.globl _XBR1
                                    281 	.globl _PCA0CPH5
                                    282 	.globl _XBR0
                                    283 	.globl _PCA0CPL5
                                    284 	.globl _ACC
                                    285 	.globl _PCA0CPM5
                                    286 	.globl _PCA0CPM4
                                    287 	.globl _PCA0CPM3
                                    288 	.globl _PCA0CPM2
                                    289 	.globl _CAN0TST
                                    290 	.globl _PCA0CPM1
                                    291 	.globl _CAN0ADR
                                    292 	.globl _PCA0CPM0
                                    293 	.globl _CAN0DATH
                                    294 	.globl _PCA0MD
                                    295 	.globl _P5
                                    296 	.globl _CAN0DATL
                                    297 	.globl _PCA0CN
                                    298 	.globl _HVA0CN
                                    299 	.globl _DAC1CN
                                    300 	.globl _DAC0CN
                                    301 	.globl _DAC1H
                                    302 	.globl _DAC0H
                                    303 	.globl _DAC1L
                                    304 	.globl _DAC0L
                                    305 	.globl _REF0CN
                                    306 	.globl _PSW
                                    307 	.globl _SMB0CR
                                    308 	.globl _TMR4H
                                    309 	.globl _TMR3H
                                    310 	.globl _TMR2H
                                    311 	.globl _TMR4L
                                    312 	.globl _TMR3L
                                    313 	.globl _TMR2L
                                    314 	.globl _RCAP4H
                                    315 	.globl _RCAP3H
                                    316 	.globl _RCAP2H
                                    317 	.globl _RCAP4L
                                    318 	.globl _RCAP3L
                                    319 	.globl _RCAP2L
                                    320 	.globl _TMR4CF
                                    321 	.globl _TMR3CF
                                    322 	.globl _TMR2CF
                                    323 	.globl _P4
                                    324 	.globl _TMR4CN
                                    325 	.globl _TMR3CN
                                    326 	.globl _TMR2CN
                                    327 	.globl _ADC0LTH
                                    328 	.globl _ADC2LT
                                    329 	.globl _ADC0LTL
                                    330 	.globl _ADC0GTH
                                    331 	.globl _ADC2GT
                                    332 	.globl _ADC0GTL
                                    333 	.globl _SMB0ADR
                                    334 	.globl _SMB0DAT
                                    335 	.globl _SMB0STA
                                    336 	.globl _CAN0STA
                                    337 	.globl _SMB0CN
                                    338 	.globl _ADC0H
                                    339 	.globl _ADC2
                                    340 	.globl _ADC0L
                                    341 	.globl _ADC2CF
                                    342 	.globl _ADC0CF
                                    343 	.globl _AMX2SL
                                    344 	.globl _AMX0SL
                                    345 	.globl _AMX0CF
                                    346 	.globl _AMX0PRT
                                    347 	.globl _AMX2CF
                                    348 	.globl _SADEN0
                                    349 	.globl _IP
                                    350 	.globl _FLACL
                                    351 	.globl _FLSCL
                                    352 	.globl _P3
                                    353 	.globl _P3MDIN
                                    354 	.globl _P2MDIN
                                    355 	.globl _P1MDIN
                                    356 	.globl _SADDR1
                                    357 	.globl _SADDR0
                                    358 	.globl _IE
                                    359 	.globl _P3MDOUT
                                    360 	.globl _P2MDOUT
                                    361 	.globl _P1MDOUT
                                    362 	.globl _P0MDOUT
                                    363 	.globl _EMI0CF
                                    364 	.globl _EMI0CN
                                    365 	.globl _EMI0TC
                                    366 	.globl _P2
                                    367 	.globl _P7MDOUT
                                    368 	.globl _P6MDOUT
                                    369 	.globl _P5MDOUT
                                    370 	.globl _SPI0CKR
                                    371 	.globl _P4MDOUT
                                    372 	.globl _SPI0DAT
                                    373 	.globl _SPI0CFG
                                    374 	.globl _SBUF1
                                    375 	.globl _SBUF0
                                    376 	.globl _SCON1
                                    377 	.globl _SCON0
                                    378 	.globl _CLKSEL
                                    379 	.globl _SFRPGCN
                                    380 	.globl _SSTA0
                                    381 	.globl _P1
                                    382 	.globl _PSCTL
                                    383 	.globl _CKCON
                                    384 	.globl _TH1
                                    385 	.globl _OSCXCN
                                    386 	.globl _TH0
                                    387 	.globl _OSCICL
                                    388 	.globl _TL1
                                    389 	.globl _OSCICN
                                    390 	.globl _TL0
                                    391 	.globl _CPT2MD
                                    392 	.globl _CPT1MD
                                    393 	.globl _CPT0MD
                                    394 	.globl _TMOD
                                    395 	.globl _CPT2CN
                                    396 	.globl _CPT1CN
                                    397 	.globl _CPT0CN
                                    398 	.globl _TCON
                                    399 	.globl _PCON
                                    400 	.globl _SFRLAST
                                    401 	.globl _SFRNEXT
                                    402 	.globl _SFRPAGE
                                    403 	.globl _DPH
                                    404 	.globl _DPL
                                    405 	.globl _SP
                                    406 	.globl _P0
                                    407 	.globl _counter
                                    408 	.globl _estado
                                    409 	.globl _tecla
                                    410 	.globl _delay_ms
                                    411 	.globl _putchar
                                    412 	.globl _int_serial
                                    413 	.globl _le_tec
                                    414 	.globl _isr_timer2
                                    415 	.globl _le_RAM_SPI
                                    416 	.globl _esc_RAM_SPI
                                    417 	.globl _test_RAM_SPI
                                    418 	.globl _le_ADC0
                                    419 	.globl _le_LM35
                                    420 	.globl _int_tc1
                                    421 	.globl _le_pulso
                                    422 ;--------------------------------------------------------
                                    423 ; special function registers
                                    424 ;--------------------------------------------------------
                                    425 	.area RSEG    (ABS,DATA)
      000000                        426 	.org 0x0000
                           000080   427 G$P0$0$0 == 0x0080
                           000080   428 _P0	=	0x0080
                           000081   429 G$SP$0$0 == 0x0081
                           000081   430 _SP	=	0x0081
                           000082   431 G$DPL$0$0 == 0x0082
                           000082   432 _DPL	=	0x0082
                           000083   433 G$DPH$0$0 == 0x0083
                           000083   434 _DPH	=	0x0083
                           000084   435 G$SFRPAGE$0$0 == 0x0084
                           000084   436 _SFRPAGE	=	0x0084
                           000085   437 G$SFRNEXT$0$0 == 0x0085
                           000085   438 _SFRNEXT	=	0x0085
                           000086   439 G$SFRLAST$0$0 == 0x0086
                           000086   440 _SFRLAST	=	0x0086
                           000087   441 G$PCON$0$0 == 0x0087
                           000087   442 _PCON	=	0x0087
                           000088   443 G$TCON$0$0 == 0x0088
                           000088   444 _TCON	=	0x0088
                           000088   445 G$CPT0CN$0$0 == 0x0088
                           000088   446 _CPT0CN	=	0x0088
                           000088   447 G$CPT1CN$0$0 == 0x0088
                           000088   448 _CPT1CN	=	0x0088
                           000088   449 G$CPT2CN$0$0 == 0x0088
                           000088   450 _CPT2CN	=	0x0088
                           000089   451 G$TMOD$0$0 == 0x0089
                           000089   452 _TMOD	=	0x0089
                           000089   453 G$CPT0MD$0$0 == 0x0089
                           000089   454 _CPT0MD	=	0x0089
                           000089   455 G$CPT1MD$0$0 == 0x0089
                           000089   456 _CPT1MD	=	0x0089
                           000089   457 G$CPT2MD$0$0 == 0x0089
                           000089   458 _CPT2MD	=	0x0089
                           00008A   459 G$TL0$0$0 == 0x008a
                           00008A   460 _TL0	=	0x008a
                           00008A   461 G$OSCICN$0$0 == 0x008a
                           00008A   462 _OSCICN	=	0x008a
                           00008B   463 G$TL1$0$0 == 0x008b
                           00008B   464 _TL1	=	0x008b
                           00008B   465 G$OSCICL$0$0 == 0x008b
                           00008B   466 _OSCICL	=	0x008b
                           00008C   467 G$TH0$0$0 == 0x008c
                           00008C   468 _TH0	=	0x008c
                           00008C   469 G$OSCXCN$0$0 == 0x008c
                           00008C   470 _OSCXCN	=	0x008c
                           00008D   471 G$TH1$0$0 == 0x008d
                           00008D   472 _TH1	=	0x008d
                           00008E   473 G$CKCON$0$0 == 0x008e
                           00008E   474 _CKCON	=	0x008e
                           00008F   475 G$PSCTL$0$0 == 0x008f
                           00008F   476 _PSCTL	=	0x008f
                           000090   477 G$P1$0$0 == 0x0090
                           000090   478 _P1	=	0x0090
                           000091   479 G$SSTA0$0$0 == 0x0091
                           000091   480 _SSTA0	=	0x0091
                           000096   481 G$SFRPGCN$0$0 == 0x0096
                           000096   482 _SFRPGCN	=	0x0096
                           000097   483 G$CLKSEL$0$0 == 0x0097
                           000097   484 _CLKSEL	=	0x0097
                           000098   485 G$SCON0$0$0 == 0x0098
                           000098   486 _SCON0	=	0x0098
                           000098   487 G$SCON1$0$0 == 0x0098
                           000098   488 _SCON1	=	0x0098
                           000099   489 G$SBUF0$0$0 == 0x0099
                           000099   490 _SBUF0	=	0x0099
                           000099   491 G$SBUF1$0$0 == 0x0099
                           000099   492 _SBUF1	=	0x0099
                           00009A   493 G$SPI0CFG$0$0 == 0x009a
                           00009A   494 _SPI0CFG	=	0x009a
                           00009B   495 G$SPI0DAT$0$0 == 0x009b
                           00009B   496 _SPI0DAT	=	0x009b
                           00009C   497 G$P4MDOUT$0$0 == 0x009c
                           00009C   498 _P4MDOUT	=	0x009c
                           00009D   499 G$SPI0CKR$0$0 == 0x009d
                           00009D   500 _SPI0CKR	=	0x009d
                           00009D   501 G$P5MDOUT$0$0 == 0x009d
                           00009D   502 _P5MDOUT	=	0x009d
                           00009E   503 G$P6MDOUT$0$0 == 0x009e
                           00009E   504 _P6MDOUT	=	0x009e
                           00009F   505 G$P7MDOUT$0$0 == 0x009f
                           00009F   506 _P7MDOUT	=	0x009f
                           0000A0   507 G$P2$0$0 == 0x00a0
                           0000A0   508 _P2	=	0x00a0
                           0000A1   509 G$EMI0TC$0$0 == 0x00a1
                           0000A1   510 _EMI0TC	=	0x00a1
                           0000A2   511 G$EMI0CN$0$0 == 0x00a2
                           0000A2   512 _EMI0CN	=	0x00a2
                           0000A3   513 G$EMI0CF$0$0 == 0x00a3
                           0000A3   514 _EMI0CF	=	0x00a3
                           0000A4   515 G$P0MDOUT$0$0 == 0x00a4
                           0000A4   516 _P0MDOUT	=	0x00a4
                           0000A5   517 G$P1MDOUT$0$0 == 0x00a5
                           0000A5   518 _P1MDOUT	=	0x00a5
                           0000A6   519 G$P2MDOUT$0$0 == 0x00a6
                           0000A6   520 _P2MDOUT	=	0x00a6
                           0000A7   521 G$P3MDOUT$0$0 == 0x00a7
                           0000A7   522 _P3MDOUT	=	0x00a7
                           0000A8   523 G$IE$0$0 == 0x00a8
                           0000A8   524 _IE	=	0x00a8
                           0000A9   525 G$SADDR0$0$0 == 0x00a9
                           0000A9   526 _SADDR0	=	0x00a9
                           0000A9   527 G$SADDR1$0$0 == 0x00a9
                           0000A9   528 _SADDR1	=	0x00a9
                           0000AD   529 G$P1MDIN$0$0 == 0x00ad
                           0000AD   530 _P1MDIN	=	0x00ad
                           0000AE   531 G$P2MDIN$0$0 == 0x00ae
                           0000AE   532 _P2MDIN	=	0x00ae
                           0000AF   533 G$P3MDIN$0$0 == 0x00af
                           0000AF   534 _P3MDIN	=	0x00af
                           0000B0   535 G$P3$0$0 == 0x00b0
                           0000B0   536 _P3	=	0x00b0
                           0000B7   537 G$FLSCL$0$0 == 0x00b7
                           0000B7   538 _FLSCL	=	0x00b7
                           0000B7   539 G$FLACL$0$0 == 0x00b7
                           0000B7   540 _FLACL	=	0x00b7
                           0000B8   541 G$IP$0$0 == 0x00b8
                           0000B8   542 _IP	=	0x00b8
                           0000B9   543 G$SADEN0$0$0 == 0x00b9
                           0000B9   544 _SADEN0	=	0x00b9
                           0000BA   545 G$AMX2CF$0$0 == 0x00ba
                           0000BA   546 _AMX2CF	=	0x00ba
                           0000BD   547 G$AMX0PRT$0$0 == 0x00bd
                           0000BD   548 _AMX0PRT	=	0x00bd
                           0000BA   549 G$AMX0CF$0$0 == 0x00ba
                           0000BA   550 _AMX0CF	=	0x00ba
                           0000BB   551 G$AMX0SL$0$0 == 0x00bb
                           0000BB   552 _AMX0SL	=	0x00bb
                           0000BB   553 G$AMX2SL$0$0 == 0x00bb
                           0000BB   554 _AMX2SL	=	0x00bb
                           0000BC   555 G$ADC0CF$0$0 == 0x00bc
                           0000BC   556 _ADC0CF	=	0x00bc
                           0000BC   557 G$ADC2CF$0$0 == 0x00bc
                           0000BC   558 _ADC2CF	=	0x00bc
                           0000BE   559 G$ADC0L$0$0 == 0x00be
                           0000BE   560 _ADC0L	=	0x00be
                           0000BE   561 G$ADC2$0$0 == 0x00be
                           0000BE   562 _ADC2	=	0x00be
                           0000BF   563 G$ADC0H$0$0 == 0x00bf
                           0000BF   564 _ADC0H	=	0x00bf
                           0000C0   565 G$SMB0CN$0$0 == 0x00c0
                           0000C0   566 _SMB0CN	=	0x00c0
                           0000C0   567 G$CAN0STA$0$0 == 0x00c0
                           0000C0   568 _CAN0STA	=	0x00c0
                           0000C1   569 G$SMB0STA$0$0 == 0x00c1
                           0000C1   570 _SMB0STA	=	0x00c1
                           0000C2   571 G$SMB0DAT$0$0 == 0x00c2
                           0000C2   572 _SMB0DAT	=	0x00c2
                           0000C3   573 G$SMB0ADR$0$0 == 0x00c3
                           0000C3   574 _SMB0ADR	=	0x00c3
                           0000C4   575 G$ADC0GTL$0$0 == 0x00c4
                           0000C4   576 _ADC0GTL	=	0x00c4
                           0000C4   577 G$ADC2GT$0$0 == 0x00c4
                           0000C4   578 _ADC2GT	=	0x00c4
                           0000C5   579 G$ADC0GTH$0$0 == 0x00c5
                           0000C5   580 _ADC0GTH	=	0x00c5
                           0000C6   581 G$ADC0LTL$0$0 == 0x00c6
                           0000C6   582 _ADC0LTL	=	0x00c6
                           0000C6   583 G$ADC2LT$0$0 == 0x00c6
                           0000C6   584 _ADC2LT	=	0x00c6
                           0000C7   585 G$ADC0LTH$0$0 == 0x00c7
                           0000C7   586 _ADC0LTH	=	0x00c7
                           0000C8   587 G$TMR2CN$0$0 == 0x00c8
                           0000C8   588 _TMR2CN	=	0x00c8
                           0000C8   589 G$TMR3CN$0$0 == 0x00c8
                           0000C8   590 _TMR3CN	=	0x00c8
                           0000C8   591 G$TMR4CN$0$0 == 0x00c8
                           0000C8   592 _TMR4CN	=	0x00c8
                           0000C8   593 G$P4$0$0 == 0x00c8
                           0000C8   594 _P4	=	0x00c8
                           0000C9   595 G$TMR2CF$0$0 == 0x00c9
                           0000C9   596 _TMR2CF	=	0x00c9
                           0000C9   597 G$TMR3CF$0$0 == 0x00c9
                           0000C9   598 _TMR3CF	=	0x00c9
                           0000C9   599 G$TMR4CF$0$0 == 0x00c9
                           0000C9   600 _TMR4CF	=	0x00c9
                           0000CA   601 G$RCAP2L$0$0 == 0x00ca
                           0000CA   602 _RCAP2L	=	0x00ca
                           0000CA   603 G$RCAP3L$0$0 == 0x00ca
                           0000CA   604 _RCAP3L	=	0x00ca
                           0000CA   605 G$RCAP4L$0$0 == 0x00ca
                           0000CA   606 _RCAP4L	=	0x00ca
                           0000CB   607 G$RCAP2H$0$0 == 0x00cb
                           0000CB   608 _RCAP2H	=	0x00cb
                           0000CB   609 G$RCAP3H$0$0 == 0x00cb
                           0000CB   610 _RCAP3H	=	0x00cb
                           0000CB   611 G$RCAP4H$0$0 == 0x00cb
                           0000CB   612 _RCAP4H	=	0x00cb
                           0000CC   613 G$TMR2L$0$0 == 0x00cc
                           0000CC   614 _TMR2L	=	0x00cc
                           0000CC   615 G$TMR3L$0$0 == 0x00cc
                           0000CC   616 _TMR3L	=	0x00cc
                           0000CC   617 G$TMR4L$0$0 == 0x00cc
                           0000CC   618 _TMR4L	=	0x00cc
                           0000CD   619 G$TMR2H$0$0 == 0x00cd
                           0000CD   620 _TMR2H	=	0x00cd
                           0000CD   621 G$TMR3H$0$0 == 0x00cd
                           0000CD   622 _TMR3H	=	0x00cd
                           0000CD   623 G$TMR4H$0$0 == 0x00cd
                           0000CD   624 _TMR4H	=	0x00cd
                           0000CF   625 G$SMB0CR$0$0 == 0x00cf
                           0000CF   626 _SMB0CR	=	0x00cf
                           0000D0   627 G$PSW$0$0 == 0x00d0
                           0000D0   628 _PSW	=	0x00d0
                           0000D1   629 G$REF0CN$0$0 == 0x00d1
                           0000D1   630 _REF0CN	=	0x00d1
                           0000D2   631 G$DAC0L$0$0 == 0x00d2
                           0000D2   632 _DAC0L	=	0x00d2
                           0000D2   633 G$DAC1L$0$0 == 0x00d2
                           0000D2   634 _DAC1L	=	0x00d2
                           0000D3   635 G$DAC0H$0$0 == 0x00d3
                           0000D3   636 _DAC0H	=	0x00d3
                           0000D3   637 G$DAC1H$0$0 == 0x00d3
                           0000D3   638 _DAC1H	=	0x00d3
                           0000D4   639 G$DAC0CN$0$0 == 0x00d4
                           0000D4   640 _DAC0CN	=	0x00d4
                           0000D4   641 G$DAC1CN$0$0 == 0x00d4
                           0000D4   642 _DAC1CN	=	0x00d4
                           0000D6   643 G$HVA0CN$0$0 == 0x00d6
                           0000D6   644 _HVA0CN	=	0x00d6
                           0000D8   645 G$PCA0CN$0$0 == 0x00d8
                           0000D8   646 _PCA0CN	=	0x00d8
                           0000D8   647 G$CAN0DATL$0$0 == 0x00d8
                           0000D8   648 _CAN0DATL	=	0x00d8
                           0000D8   649 G$P5$0$0 == 0x00d8
                           0000D8   650 _P5	=	0x00d8
                           0000D9   651 G$PCA0MD$0$0 == 0x00d9
                           0000D9   652 _PCA0MD	=	0x00d9
                           0000D9   653 G$CAN0DATH$0$0 == 0x00d9
                           0000D9   654 _CAN0DATH	=	0x00d9
                           0000DA   655 G$PCA0CPM0$0$0 == 0x00da
                           0000DA   656 _PCA0CPM0	=	0x00da
                           0000DA   657 G$CAN0ADR$0$0 == 0x00da
                           0000DA   658 _CAN0ADR	=	0x00da
                           0000DB   659 G$PCA0CPM1$0$0 == 0x00db
                           0000DB   660 _PCA0CPM1	=	0x00db
                           0000DB   661 G$CAN0TST$0$0 == 0x00db
                           0000DB   662 _CAN0TST	=	0x00db
                           0000DC   663 G$PCA0CPM2$0$0 == 0x00dc
                           0000DC   664 _PCA0CPM2	=	0x00dc
                           0000DD   665 G$PCA0CPM3$0$0 == 0x00dd
                           0000DD   666 _PCA0CPM3	=	0x00dd
                           0000DE   667 G$PCA0CPM4$0$0 == 0x00de
                           0000DE   668 _PCA0CPM4	=	0x00de
                           0000DF   669 G$PCA0CPM5$0$0 == 0x00df
                           0000DF   670 _PCA0CPM5	=	0x00df
                           0000E0   671 G$ACC$0$0 == 0x00e0
                           0000E0   672 _ACC	=	0x00e0
                           0000E1   673 G$PCA0CPL5$0$0 == 0x00e1
                           0000E1   674 _PCA0CPL5	=	0x00e1
                           0000E1   675 G$XBR0$0$0 == 0x00e1
                           0000E1   676 _XBR0	=	0x00e1
                           0000E2   677 G$PCA0CPH5$0$0 == 0x00e2
                           0000E2   678 _PCA0CPH5	=	0x00e2
                           0000E2   679 G$XBR1$0$0 == 0x00e2
                           0000E2   680 _XBR1	=	0x00e2
                           0000E3   681 G$XBR2$0$0 == 0x00e3
                           0000E3   682 _XBR2	=	0x00e3
                           0000E4   683 G$XBR3$0$0 == 0x00e4
                           0000E4   684 _XBR3	=	0x00e4
                           0000E6   685 G$EIE1$0$0 == 0x00e6
                           0000E6   686 _EIE1	=	0x00e6
                           0000E7   687 G$EIE2$0$0 == 0x00e7
                           0000E7   688 _EIE2	=	0x00e7
                           0000E8   689 G$ADC0CN$0$0 == 0x00e8
                           0000E8   690 _ADC0CN	=	0x00e8
                           0000E8   691 G$ADC2CN$0$0 == 0x00e8
                           0000E8   692 _ADC2CN	=	0x00e8
                           0000E8   693 G$P6$0$0 == 0x00e8
                           0000E8   694 _P6	=	0x00e8
                           0000E9   695 G$PCA0CPL2$0$0 == 0x00e9
                           0000E9   696 _PCA0CPL2	=	0x00e9
                           0000EA   697 G$PCA0CPH2$0$0 == 0x00ea
                           0000EA   698 _PCA0CPH2	=	0x00ea
                           0000EB   699 G$PCA0CPL3$0$0 == 0x00eb
                           0000EB   700 _PCA0CPL3	=	0x00eb
                           0000EC   701 G$PCA0CPH3$0$0 == 0x00ec
                           0000EC   702 _PCA0CPH3	=	0x00ec
                           0000ED   703 G$PCA0CPL4$0$0 == 0x00ed
                           0000ED   704 _PCA0CPL4	=	0x00ed
                           0000EE   705 G$PCA0CPH4$0$0 == 0x00ee
                           0000EE   706 _PCA0CPH4	=	0x00ee
                           0000EF   707 G$RSTSRC$0$0 == 0x00ef
                           0000EF   708 _RSTSRC	=	0x00ef
                           0000F0   709 G$B$0$0 == 0x00f0
                           0000F0   710 _B	=	0x00f0
                           0000F6   711 G$EIP1$0$0 == 0x00f6
                           0000F6   712 _EIP1	=	0x00f6
                           0000F7   713 G$EIP2$0$0 == 0x00f7
                           0000F7   714 _EIP2	=	0x00f7
                           0000F8   715 G$SPI0CN$0$0 == 0x00f8
                           0000F8   716 _SPI0CN	=	0x00f8
                           0000F8   717 G$CAN0CN$0$0 == 0x00f8
                           0000F8   718 _CAN0CN	=	0x00f8
                           0000F8   719 G$P7$0$0 == 0x00f8
                           0000F8   720 _P7	=	0x00f8
                           0000F9   721 G$PCA0L$0$0 == 0x00f9
                           0000F9   722 _PCA0L	=	0x00f9
                           0000FA   723 G$PCA0H$0$0 == 0x00fa
                           0000FA   724 _PCA0H	=	0x00fa
                           0000FB   725 G$PCA0CPL0$0$0 == 0x00fb
                           0000FB   726 _PCA0CPL0	=	0x00fb
                           0000FC   727 G$PCA0CPH0$0$0 == 0x00fc
                           0000FC   728 _PCA0CPH0	=	0x00fc
                           0000FD   729 G$PCA0CPL1$0$0 == 0x00fd
                           0000FD   730 _PCA0CPL1	=	0x00fd
                           0000FE   731 G$PCA0CPH1$0$0 == 0x00fe
                           0000FE   732 _PCA0CPH1	=	0x00fe
                           0000FF   733 G$WDTCN$0$0 == 0x00ff
                           0000FF   734 _WDTCN	=	0x00ff
                           00FAF9   735 G$PCA0$0$0 == 0xfaf9
                           00FAF9   736 _PCA0	=	0xfaf9
                           00FCFB   737 G$PCA0CP0$0$0 == 0xfcfb
                           00FCFB   738 _PCA0CP0	=	0xfcfb
                           00FEFD   739 G$PCA0CP1$0$0 == 0xfefd
                           00FEFD   740 _PCA0CP1	=	0xfefd
                           00EAE9   741 G$PCA0CP2$0$0 == 0xeae9
                           00EAE9   742 _PCA0CP2	=	0xeae9
                           00ECEB   743 G$PCA0CP3$0$0 == 0xeceb
                           00ECEB   744 _PCA0CP3	=	0xeceb
                           00EEED   745 G$PCA0CP4$0$0 == 0xeeed
                           00EEED   746 _PCA0CP4	=	0xeeed
                           00E2E1   747 G$PCA0CP5$0$0 == 0xe2e1
                           00E2E1   748 _PCA0CP5	=	0xe2e1
                           00D9D8   749 G$CAN0DAT$0$0 == 0xd9d8
                           00D9D8   750 _CAN0DAT	=	0xd9d8
                           00D3D2   751 G$DAC0$0$0 == 0xd3d2
                           00D3D2   752 _DAC0	=	0xd3d2
                           00D3D2   753 G$DAC1$0$0 == 0xd3d2
                           00D3D2   754 _DAC1	=	0xd3d2
                           00CBCA   755 G$RCAP2$0$0 == 0xcbca
                           00CBCA   756 _RCAP2	=	0xcbca
                           00CBCA   757 G$RCAP3$0$0 == 0xcbca
                           00CBCA   758 _RCAP3	=	0xcbca
                           00CBCA   759 G$RCAP4$0$0 == 0xcbca
                           00CBCA   760 _RCAP4	=	0xcbca
                           00CDCC   761 G$TMR2$0$0 == 0xcdcc
                           00CDCC   762 _TMR2	=	0xcdcc
                           00CDCC   763 G$TMR3$0$0 == 0xcdcc
                           00CDCC   764 _TMR3	=	0xcdcc
                           00CDCC   765 G$TMR4$0$0 == 0xcdcc
                           00CDCC   766 _TMR4	=	0xcdcc
                           00C5C4   767 G$ADC0GT$0$0 == 0xc5c4
                           00C5C4   768 _ADC0GT	=	0xc5c4
                           00C7C6   769 G$ADC0LT$0$0 == 0xc7c6
                           00C7C6   770 _ADC0LT	=	0xc7c6
                           00BFBE   771 G$ADC0$0$0 == 0xbfbe
                           00BFBE   772 _ADC0	=	0xbfbe
                           008382   773 G$DP$0$0 == 0x8382
                           008382   774 _DP	=	0x8382
                                    775 ;--------------------------------------------------------
                                    776 ; special function bits
                                    777 ;--------------------------------------------------------
                                    778 	.area RSEG    (ABS,DATA)
      000000                        779 	.org 0x0000
                           000080   780 G$P0_0$0$0 == 0x0080
                           000080   781 _P0_0	=	0x0080
                           000081   782 G$P0_1$0$0 == 0x0081
                           000081   783 _P0_1	=	0x0081
                           000082   784 G$P0_2$0$0 == 0x0082
                           000082   785 _P0_2	=	0x0082
                           000083   786 G$P0_3$0$0 == 0x0083
                           000083   787 _P0_3	=	0x0083
                           000084   788 G$P0_4$0$0 == 0x0084
                           000084   789 _P0_4	=	0x0084
                           000085   790 G$P0_5$0$0 == 0x0085
                           000085   791 _P0_5	=	0x0085
                           000086   792 G$P0_6$0$0 == 0x0086
                           000086   793 _P0_6	=	0x0086
                           000087   794 G$P0_7$0$0 == 0x0087
                           000087   795 _P0_7	=	0x0087
                           000090   796 G$P1_0$0$0 == 0x0090
                           000090   797 _P1_0	=	0x0090
                           000091   798 G$P1_1$0$0 == 0x0091
                           000091   799 _P1_1	=	0x0091
                           000092   800 G$P1_2$0$0 == 0x0092
                           000092   801 _P1_2	=	0x0092
                           000093   802 G$P1_3$0$0 == 0x0093
                           000093   803 _P1_3	=	0x0093
                           000094   804 G$P1_4$0$0 == 0x0094
                           000094   805 _P1_4	=	0x0094
                           000095   806 G$P1_5$0$0 == 0x0095
                           000095   807 _P1_5	=	0x0095
                           000096   808 G$P1_6$0$0 == 0x0096
                           000096   809 _P1_6	=	0x0096
                           000097   810 G$P1_7$0$0 == 0x0097
                           000097   811 _P1_7	=	0x0097
                           0000A0   812 G$P2_0$0$0 == 0x00a0
                           0000A0   813 _P2_0	=	0x00a0
                           0000A1   814 G$P2_1$0$0 == 0x00a1
                           0000A1   815 _P2_1	=	0x00a1
                           0000A2   816 G$P2_2$0$0 == 0x00a2
                           0000A2   817 _P2_2	=	0x00a2
                           0000A3   818 G$P2_3$0$0 == 0x00a3
                           0000A3   819 _P2_3	=	0x00a3
                           0000A4   820 G$P2_4$0$0 == 0x00a4
                           0000A4   821 _P2_4	=	0x00a4
                           0000A5   822 G$P2_5$0$0 == 0x00a5
                           0000A5   823 _P2_5	=	0x00a5
                           0000A6   824 G$P2_6$0$0 == 0x00a6
                           0000A6   825 _P2_6	=	0x00a6
                           0000A7   826 G$P2_7$0$0 == 0x00a7
                           0000A7   827 _P2_7	=	0x00a7
                           0000B0   828 G$P3_0$0$0 == 0x00b0
                           0000B0   829 _P3_0	=	0x00b0
                           0000B1   830 G$P3_1$0$0 == 0x00b1
                           0000B1   831 _P3_1	=	0x00b1
                           0000B2   832 G$P3_2$0$0 == 0x00b2
                           0000B2   833 _P3_2	=	0x00b2
                           0000B3   834 G$P3_3$0$0 == 0x00b3
                           0000B3   835 _P3_3	=	0x00b3
                           0000B4   836 G$P3_4$0$0 == 0x00b4
                           0000B4   837 _P3_4	=	0x00b4
                           0000B5   838 G$P3_5$0$0 == 0x00b5
                           0000B5   839 _P3_5	=	0x00b5
                           0000B6   840 G$P3_6$0$0 == 0x00b6
                           0000B6   841 _P3_6	=	0x00b6
                           0000B7   842 G$P3_7$0$0 == 0x00b7
                           0000B7   843 _P3_7	=	0x00b7
                           0000C8   844 G$P4_0$0$0 == 0x00c8
                           0000C8   845 _P4_0	=	0x00c8
                           0000C9   846 G$P4_1$0$0 == 0x00c9
                           0000C9   847 _P4_1	=	0x00c9
                           0000CA   848 G$P4_2$0$0 == 0x00ca
                           0000CA   849 _P4_2	=	0x00ca
                           0000CB   850 G$P4_3$0$0 == 0x00cb
                           0000CB   851 _P4_3	=	0x00cb
                           0000CC   852 G$P4_4$0$0 == 0x00cc
                           0000CC   853 _P4_4	=	0x00cc
                           0000CD   854 G$P4_5$0$0 == 0x00cd
                           0000CD   855 _P4_5	=	0x00cd
                           0000CE   856 G$P4_6$0$0 == 0x00ce
                           0000CE   857 _P4_6	=	0x00ce
                           0000CF   858 G$P4_7$0$0 == 0x00cf
                           0000CF   859 _P4_7	=	0x00cf
                           0000D8   860 G$P5_0$0$0 == 0x00d8
                           0000D8   861 _P5_0	=	0x00d8
                           0000D9   862 G$P5_1$0$0 == 0x00d9
                           0000D9   863 _P5_1	=	0x00d9
                           0000DA   864 G$P5_2$0$0 == 0x00da
                           0000DA   865 _P5_2	=	0x00da
                           0000DB   866 G$P5_3$0$0 == 0x00db
                           0000DB   867 _P5_3	=	0x00db
                           0000DC   868 G$P5_4$0$0 == 0x00dc
                           0000DC   869 _P5_4	=	0x00dc
                           0000DD   870 G$P5_5$0$0 == 0x00dd
                           0000DD   871 _P5_5	=	0x00dd
                           0000DE   872 G$P5_6$0$0 == 0x00de
                           0000DE   873 _P5_6	=	0x00de
                           0000DF   874 G$P5_7$0$0 == 0x00df
                           0000DF   875 _P5_7	=	0x00df
                           0000E8   876 G$P6_0$0$0 == 0x00e8
                           0000E8   877 _P6_0	=	0x00e8
                           0000E9   878 G$P6_1$0$0 == 0x00e9
                           0000E9   879 _P6_1	=	0x00e9
                           0000EA   880 G$P6_2$0$0 == 0x00ea
                           0000EA   881 _P6_2	=	0x00ea
                           0000EB   882 G$P6_3$0$0 == 0x00eb
                           0000EB   883 _P6_3	=	0x00eb
                           0000EC   884 G$P6_4$0$0 == 0x00ec
                           0000EC   885 _P6_4	=	0x00ec
                           0000ED   886 G$P6_5$0$0 == 0x00ed
                           0000ED   887 _P6_5	=	0x00ed
                           0000EE   888 G$P6_6$0$0 == 0x00ee
                           0000EE   889 _P6_6	=	0x00ee
                           0000EF   890 G$P6_7$0$0 == 0x00ef
                           0000EF   891 _P6_7	=	0x00ef
                           0000F8   892 G$P7_0$0$0 == 0x00f8
                           0000F8   893 _P7_0	=	0x00f8
                           0000F9   894 G$P7_1$0$0 == 0x00f9
                           0000F9   895 _P7_1	=	0x00f9
                           0000FA   896 G$P7_2$0$0 == 0x00fa
                           0000FA   897 _P7_2	=	0x00fa
                           0000FB   898 G$P7_3$0$0 == 0x00fb
                           0000FB   899 _P7_3	=	0x00fb
                           0000FC   900 G$P7_4$0$0 == 0x00fc
                           0000FC   901 _P7_4	=	0x00fc
                           0000FD   902 G$P7_5$0$0 == 0x00fd
                           0000FD   903 _P7_5	=	0x00fd
                           0000FE   904 G$P7_6$0$0 == 0x00fe
                           0000FE   905 _P7_6	=	0x00fe
                           0000FF   906 G$P7_7$0$0 == 0x00ff
                           0000FF   907 _P7_7	=	0x00ff
                           00008F   908 G$TF1$0$0 == 0x008f
                           00008F   909 _TF1	=	0x008f
                           00008E   910 G$TR1$0$0 == 0x008e
                           00008E   911 _TR1	=	0x008e
                           00008D   912 G$TF0$0$0 == 0x008d
                           00008D   913 _TF0	=	0x008d
                           00008C   914 G$TR0$0$0 == 0x008c
                           00008C   915 _TR0	=	0x008c
                           00008B   916 G$IE1$0$0 == 0x008b
                           00008B   917 _IE1	=	0x008b
                           00008A   918 G$IT1$0$0 == 0x008a
                           00008A   919 _IT1	=	0x008a
                           000089   920 G$IE0$0$0 == 0x0089
                           000089   921 _IE0	=	0x0089
                           000088   922 G$IT0$0$0 == 0x0088
                           000088   923 _IT0	=	0x0088
                           00008F   924 G$CP0EN$0$0 == 0x008f
                           00008F   925 _CP0EN	=	0x008f
                           00008E   926 G$CP0OUT$0$0 == 0x008e
                           00008E   927 _CP0OUT	=	0x008e
                           00008D   928 G$CP0RIF$0$0 == 0x008d
                           00008D   929 _CP0RIF	=	0x008d
                           00008C   930 G$CP0FIF$0$0 == 0x008c
                           00008C   931 _CP0FIF	=	0x008c
                           00008B   932 G$CP0HYP1$0$0 == 0x008b
                           00008B   933 _CP0HYP1	=	0x008b
                           00008A   934 G$CP0HYP0$0$0 == 0x008a
                           00008A   935 _CP0HYP0	=	0x008a
                           000089   936 G$CP0HYN1$0$0 == 0x0089
                           000089   937 _CP0HYN1	=	0x0089
                           000088   938 G$CP0HYN0$0$0 == 0x0088
                           000088   939 _CP0HYN0	=	0x0088
                           00008F   940 G$CP1EN$0$0 == 0x008f
                           00008F   941 _CP1EN	=	0x008f
                           00008E   942 G$CP1OUT$0$0 == 0x008e
                           00008E   943 _CP1OUT	=	0x008e
                           00008D   944 G$CP1RIF$0$0 == 0x008d
                           00008D   945 _CP1RIF	=	0x008d
                           00008C   946 G$CP1FIF$0$0 == 0x008c
                           00008C   947 _CP1FIF	=	0x008c
                           00008B   948 G$CP1HYP1$0$0 == 0x008b
                           00008B   949 _CP1HYP1	=	0x008b
                           00008A   950 G$CP1HYP0$0$0 == 0x008a
                           00008A   951 _CP1HYP0	=	0x008a
                           000089   952 G$CP1HYN1$0$0 == 0x0089
                           000089   953 _CP1HYN1	=	0x0089
                           000088   954 G$CP1HYN0$0$0 == 0x0088
                           000088   955 _CP1HYN0	=	0x0088
                           00008F   956 G$CP2EN$0$0 == 0x008f
                           00008F   957 _CP2EN	=	0x008f
                           00008E   958 G$CP2OUT$0$0 == 0x008e
                           00008E   959 _CP2OUT	=	0x008e
                           00008D   960 G$CP2RIF$0$0 == 0x008d
                           00008D   961 _CP2RIF	=	0x008d
                           00008C   962 G$CP2FIF$0$0 == 0x008c
                           00008C   963 _CP2FIF	=	0x008c
                           00008B   964 G$CP2HYP1$0$0 == 0x008b
                           00008B   965 _CP2HYP1	=	0x008b
                           00008A   966 G$CP2HYP0$0$0 == 0x008a
                           00008A   967 _CP2HYP0	=	0x008a
                           000089   968 G$CP2HYN1$0$0 == 0x0089
                           000089   969 _CP2HYN1	=	0x0089
                           000088   970 G$CP2HYN0$0$0 == 0x0088
                           000088   971 _CP2HYN0	=	0x0088
                           00009F   972 G$SM00$0$0 == 0x009f
                           00009F   973 _SM00	=	0x009f
                           00009E   974 G$SM10$0$0 == 0x009e
                           00009E   975 _SM10	=	0x009e
                           00009D   976 G$SM20$0$0 == 0x009d
                           00009D   977 _SM20	=	0x009d
                           00009C   978 G$REN0$0$0 == 0x009c
                           00009C   979 _REN0	=	0x009c
                           00009B   980 G$TB80$0$0 == 0x009b
                           00009B   981 _TB80	=	0x009b
                           00009A   982 G$RB80$0$0 == 0x009a
                           00009A   983 _RB80	=	0x009a
                           000099   984 G$TI0$0$0 == 0x0099
                           000099   985 _TI0	=	0x0099
                           000098   986 G$RI0$0$0 == 0x0098
                           000098   987 _RI0	=	0x0098
                           00009F   988 G$S1MODE$0$0 == 0x009f
                           00009F   989 _S1MODE	=	0x009f
                           00009D   990 G$MCE1$0$0 == 0x009d
                           00009D   991 _MCE1	=	0x009d
                           00009C   992 G$REN1$0$0 == 0x009c
                           00009C   993 _REN1	=	0x009c
                           00009B   994 G$TB81$0$0 == 0x009b
                           00009B   995 _TB81	=	0x009b
                           00009A   996 G$RB81$0$0 == 0x009a
                           00009A   997 _RB81	=	0x009a
                           000099   998 G$TI1$0$0 == 0x0099
                           000099   999 _TI1	=	0x0099
                           000098  1000 G$RI1$0$0 == 0x0098
                           000098  1001 _RI1	=	0x0098
                           0000AF  1002 G$EA$0$0 == 0x00af
                           0000AF  1003 _EA	=	0x00af
                           0000AD  1004 G$ET2$0$0 == 0x00ad
                           0000AD  1005 _ET2	=	0x00ad
                           0000AC  1006 G$ES0$0$0 == 0x00ac
                           0000AC  1007 _ES0	=	0x00ac
                           0000AB  1008 G$ET1$0$0 == 0x00ab
                           0000AB  1009 _ET1	=	0x00ab
                           0000AA  1010 G$EX1$0$0 == 0x00aa
                           0000AA  1011 _EX1	=	0x00aa
                           0000A9  1012 G$ET0$0$0 == 0x00a9
                           0000A9  1013 _ET0	=	0x00a9
                           0000A8  1014 G$EX0$0$0 == 0x00a8
                           0000A8  1015 _EX0	=	0x00a8
                           0000BD  1016 G$PT2$0$0 == 0x00bd
                           0000BD  1017 _PT2	=	0x00bd
                           0000BC  1018 G$PS0$0$0 == 0x00bc
                           0000BC  1019 _PS0	=	0x00bc
                           0000BB  1020 G$PT1$0$0 == 0x00bb
                           0000BB  1021 _PT1	=	0x00bb
                           0000BA  1022 G$PX1$0$0 == 0x00ba
                           0000BA  1023 _PX1	=	0x00ba
                           0000B9  1024 G$PT0$0$0 == 0x00b9
                           0000B9  1025 _PT0	=	0x00b9
                           0000B8  1026 G$PX0$0$0 == 0x00b8
                           0000B8  1027 _PX0	=	0x00b8
                           0000C7  1028 G$BUSY$0$0 == 0x00c7
                           0000C7  1029 _BUSY	=	0x00c7
                           0000C6  1030 G$ENSMB$0$0 == 0x00c6
                           0000C6  1031 _ENSMB	=	0x00c6
                           0000C5  1032 G$STA$0$0 == 0x00c5
                           0000C5  1033 _STA	=	0x00c5
                           0000C4  1034 G$STO$0$0 == 0x00c4
                           0000C4  1035 _STO	=	0x00c4
                           0000C3  1036 G$SI$0$0 == 0x00c3
                           0000C3  1037 _SI	=	0x00c3
                           0000C2  1038 G$AA$0$0 == 0x00c2
                           0000C2  1039 _AA	=	0x00c2
                           0000C1  1040 G$SMBFTE$0$0 == 0x00c1
                           0000C1  1041 _SMBFTE	=	0x00c1
                           0000C0  1042 G$SMBTOE$0$0 == 0x00c0
                           0000C0  1043 _SMBTOE	=	0x00c0
                           0000C7  1044 G$BOFF$0$0 == 0x00c7
                           0000C7  1045 _BOFF	=	0x00c7
                           0000C6  1046 G$EWARN$0$0 == 0x00c6
                           0000C6  1047 _EWARN	=	0x00c6
                           0000C5  1048 G$EPASS$0$0 == 0x00c5
                           0000C5  1049 _EPASS	=	0x00c5
                           0000C4  1050 G$RXOK$0$0 == 0x00c4
                           0000C4  1051 _RXOK	=	0x00c4
                           0000C3  1052 G$TXOK$0$0 == 0x00c3
                           0000C3  1053 _TXOK	=	0x00c3
                           0000C2  1054 G$LEC2$0$0 == 0x00c2
                           0000C2  1055 _LEC2	=	0x00c2
                           0000C1  1056 G$LEC1$0$0 == 0x00c1
                           0000C1  1057 _LEC1	=	0x00c1
                           0000C0  1058 G$LEC0$0$0 == 0x00c0
                           0000C0  1059 _LEC0	=	0x00c0
                           0000CF  1060 G$TF2$0$0 == 0x00cf
                           0000CF  1061 _TF2	=	0x00cf
                           0000CE  1062 G$EXF2$0$0 == 0x00ce
                           0000CE  1063 _EXF2	=	0x00ce
                           0000CB  1064 G$EXEN2$0$0 == 0x00cb
                           0000CB  1065 _EXEN2	=	0x00cb
                           0000CA  1066 G$TR2$0$0 == 0x00ca
                           0000CA  1067 _TR2	=	0x00ca
                           0000C9  1068 G$CT2$0$0 == 0x00c9
                           0000C9  1069 _CT2	=	0x00c9
                           0000C8  1070 G$CPRL2$0$0 == 0x00c8
                           0000C8  1071 _CPRL2	=	0x00c8
                           0000CF  1072 G$TF3$0$0 == 0x00cf
                           0000CF  1073 _TF3	=	0x00cf
                           0000CE  1074 G$EXF3$0$0 == 0x00ce
                           0000CE  1075 _EXF3	=	0x00ce
                           0000CB  1076 G$EXEN3$0$0 == 0x00cb
                           0000CB  1077 _EXEN3	=	0x00cb
                           0000CA  1078 G$TR3$0$0 == 0x00ca
                           0000CA  1079 _TR3	=	0x00ca
                           0000C9  1080 G$CT3$0$0 == 0x00c9
                           0000C9  1081 _CT3	=	0x00c9
                           0000C8  1082 G$CPRL3$0$0 == 0x00c8
                           0000C8  1083 _CPRL3	=	0x00c8
                           0000CF  1084 G$TF4$0$0 == 0x00cf
                           0000CF  1085 _TF4	=	0x00cf
                           0000CE  1086 G$EXF4$0$0 == 0x00ce
                           0000CE  1087 _EXF4	=	0x00ce
                           0000CB  1088 G$EXEN4$0$0 == 0x00cb
                           0000CB  1089 _EXEN4	=	0x00cb
                           0000CA  1090 G$TR4$0$0 == 0x00ca
                           0000CA  1091 _TR4	=	0x00ca
                           0000C9  1092 G$CT4$0$0 == 0x00c9
                           0000C9  1093 _CT4	=	0x00c9
                           0000C8  1094 G$CPRL4$0$0 == 0x00c8
                           0000C8  1095 _CPRL4	=	0x00c8
                           0000D7  1096 G$CY$0$0 == 0x00d7
                           0000D7  1097 _CY	=	0x00d7
                           0000D6  1098 G$AC$0$0 == 0x00d6
                           0000D6  1099 _AC	=	0x00d6
                           0000D5  1100 G$F0$0$0 == 0x00d5
                           0000D5  1101 _F0	=	0x00d5
                           0000D4  1102 G$RS1$0$0 == 0x00d4
                           0000D4  1103 _RS1	=	0x00d4
                           0000D3  1104 G$RS0$0$0 == 0x00d3
                           0000D3  1105 _RS0	=	0x00d3
                           0000D2  1106 G$OV$0$0 == 0x00d2
                           0000D2  1107 _OV	=	0x00d2
                           0000D1  1108 G$F1$0$0 == 0x00d1
                           0000D1  1109 _F1	=	0x00d1
                           0000D0  1110 G$P$0$0 == 0x00d0
                           0000D0  1111 _P	=	0x00d0
                           0000DF  1112 G$CF$0$0 == 0x00df
                           0000DF  1113 _CF	=	0x00df
                           0000DE  1114 G$CR$0$0 == 0x00de
                           0000DE  1115 _CR	=	0x00de
                           0000DD  1116 G$CCF5$0$0 == 0x00dd
                           0000DD  1117 _CCF5	=	0x00dd
                           0000DC  1118 G$CCF4$0$0 == 0x00dc
                           0000DC  1119 _CCF4	=	0x00dc
                           0000DB  1120 G$CCF3$0$0 == 0x00db
                           0000DB  1121 _CCF3	=	0x00db
                           0000DA  1122 G$CCF2$0$0 == 0x00da
                           0000DA  1123 _CCF2	=	0x00da
                           0000D9  1124 G$CCF1$0$0 == 0x00d9
                           0000D9  1125 _CCF1	=	0x00d9
                           0000D8  1126 G$CCF0$0$0 == 0x00d8
                           0000D8  1127 _CCF0	=	0x00d8
                           0000EF  1128 G$AD0EN$0$0 == 0x00ef
                           0000EF  1129 _AD0EN	=	0x00ef
                           0000EE  1130 G$AD0TM$0$0 == 0x00ee
                           0000EE  1131 _AD0TM	=	0x00ee
                           0000ED  1132 G$AD0INT$0$0 == 0x00ed
                           0000ED  1133 _AD0INT	=	0x00ed
                           0000EC  1134 G$AD0BUSY$0$0 == 0x00ec
                           0000EC  1135 _AD0BUSY	=	0x00ec
                           0000EB  1136 G$AD0CM1$0$0 == 0x00eb
                           0000EB  1137 _AD0CM1	=	0x00eb
                           0000EA  1138 G$AD0CM0$0$0 == 0x00ea
                           0000EA  1139 _AD0CM0	=	0x00ea
                           0000E9  1140 G$AD0WINT$0$0 == 0x00e9
                           0000E9  1141 _AD0WINT	=	0x00e9
                           0000E8  1142 G$AD0LJST$0$0 == 0x00e8
                           0000E8  1143 _AD0LJST	=	0x00e8
                           0000EF  1144 G$AD2EN$0$0 == 0x00ef
                           0000EF  1145 _AD2EN	=	0x00ef
                           0000EE  1146 G$AD2TM$0$0 == 0x00ee
                           0000EE  1147 _AD2TM	=	0x00ee
                           0000ED  1148 G$AD2INT$0$0 == 0x00ed
                           0000ED  1149 _AD2INT	=	0x00ed
                           0000EC  1150 G$AD2BUSY$0$0 == 0x00ec
                           0000EC  1151 _AD2BUSY	=	0x00ec
                           0000EB  1152 G$AD2CM2$0$0 == 0x00eb
                           0000EB  1153 _AD2CM2	=	0x00eb
                           0000EA  1154 G$AD2CM1$0$0 == 0x00ea
                           0000EA  1155 _AD2CM1	=	0x00ea
                           0000E9  1156 G$AD2CM0$0$0 == 0x00e9
                           0000E9  1157 _AD2CM0	=	0x00e9
                           0000E8  1158 G$AD2WINT$0$0 == 0x00e8
                           0000E8  1159 _AD2WINT	=	0x00e8
                           0000FF  1160 G$SPIF$0$0 == 0x00ff
                           0000FF  1161 _SPIF	=	0x00ff
                           0000FE  1162 G$WCOL$0$0 == 0x00fe
                           0000FE  1163 _WCOL	=	0x00fe
                           0000FD  1164 G$MODF$0$0 == 0x00fd
                           0000FD  1165 _MODF	=	0x00fd
                           0000FC  1166 G$RXOVRN$0$0 == 0x00fc
                           0000FC  1167 _RXOVRN	=	0x00fc
                           0000FB  1168 G$NSSMD1$0$0 == 0x00fb
                           0000FB  1169 _NSSMD1	=	0x00fb
                           0000FA  1170 G$NSSMD0$0$0 == 0x00fa
                           0000FA  1171 _NSSMD0	=	0x00fa
                           0000F9  1172 G$TXBMT$0$0 == 0x00f9
                           0000F9  1173 _TXBMT	=	0x00f9
                           0000F8  1174 G$SPIEN$0$0 == 0x00f8
                           0000F8  1175 _SPIEN	=	0x00f8
                           0000F8  1176 G$CANINIT$0$0 == 0x00f8
                           0000F8  1177 _CANINIT	=	0x00f8
                           0000F9  1178 G$CANIE$0$0 == 0x00f9
                           0000F9  1179 _CANIE	=	0x00f9
                           0000FA  1180 G$CANSIE$0$0 == 0x00fa
                           0000FA  1181 _CANSIE	=	0x00fa
                           0000FB  1182 G$CANEIE$0$0 == 0x00fb
                           0000FB  1183 _CANEIE	=	0x00fb
                           0000FC  1184 G$CANIF$0$0 == 0x00fc
                           0000FC  1185 _CANIF	=	0x00fc
                           0000FD  1186 G$CANDAR$0$0 == 0x00fd
                           0000FD  1187 _CANDAR	=	0x00fd
                           0000FE  1188 G$CANCCE$0$0 == 0x00fe
                           0000FE  1189 _CANCCE	=	0x00fe
                           0000FF  1190 G$CANTEST$0$0 == 0x00ff
                           0000FF  1191 _CANTEST	=	0x00ff
                                   1192 ;--------------------------------------------------------
                                   1193 ; overlayable register banks
                                   1194 ;--------------------------------------------------------
                                   1195 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                       1196 	.ds 8
                                   1197 ;--------------------------------------------------------
                                   1198 ; overlayable bit register bank
                                   1199 ;--------------------------------------------------------
                                   1200 	.area BIT_BANK	(REL,OVR,DATA)
      000021                       1201 bits:
      000021                       1202 	.ds 1
                           008000  1203 	b0 = bits[0]
                           008100  1204 	b1 = bits[1]
                           008200  1205 	b2 = bits[2]
                           008300  1206 	b3 = bits[3]
                           008400  1207 	b4 = bits[4]
                           008500  1208 	b5 = bits[5]
                           008600  1209 	b6 = bits[6]
                           008700  1210 	b7 = bits[7]
                                   1211 ;--------------------------------------------------------
                                   1212 ; internal ram data
                                   1213 ;--------------------------------------------------------
                                   1214 	.area DSEG    (DATA)
                           000000  1215 G$tecla$0$0==.
      000008                       1216 _tecla::
      000008                       1217 	.ds 1
                           000001  1218 G$estado$0$0==.
      000009                       1219 _estado::
      000009                       1220 	.ds 1
                           000002  1221 G$counter$0$0==.
      00000A                       1222 _counter::
      00000A                       1223 	.ds 4
                                   1224 ;--------------------------------------------------------
                                   1225 ; overlayable items in internal ram 
                                   1226 ;--------------------------------------------------------
                                   1227 	.area	OSEG    (OVR,DATA)
                                   1228 	.area	OSEG    (OVR,DATA)
                                   1229 	.area	OSEG    (OVR,DATA)
                                   1230 	.area	OSEG    (OVR,DATA)
                                   1231 	.area	OSEG    (OVR,DATA)
                           000000  1232 Lp3main.esc_RAM_SPI$dado$1$55==.
      000015                       1233 _esc_RAM_SPI_PARM_2:
      000015                       1234 	.ds 1
                                   1235 	.area	OSEG    (OVR,DATA)
                           000000  1236 Lp3main.le_ADC0$ganho$1$60==.
      000015                       1237 _le_ADC0_PARM_2:
      000015                       1238 	.ds 1
                                   1239 ;--------------------------------------------------------
                                   1240 ; Stack segment in internal ram 
                                   1241 ;--------------------------------------------------------
                                   1242 	.area	SSEG
      000022                       1243 __start__stack:
      000022                       1244 	.ds	1
                                   1245 
                                   1246 ;--------------------------------------------------------
                                   1247 ; indirectly addressable internal ram data
                                   1248 ;--------------------------------------------------------
                                   1249 	.area ISEG    (DATA)
                                   1250 ;--------------------------------------------------------
                                   1251 ; absolute internal ram data
                                   1252 ;--------------------------------------------------------
                                   1253 	.area IABS    (ABS,DATA)
                                   1254 	.area IABS    (ABS,DATA)
                                   1255 ;--------------------------------------------------------
                                   1256 ; bit data
                                   1257 ;--------------------------------------------------------
                                   1258 	.area BSEG    (BIT)
                                   1259 ;--------------------------------------------------------
                                   1260 ; paged external ram data
                                   1261 ;--------------------------------------------------------
                                   1262 	.area PSEG    (PAG,XDATA)
                                   1263 ;--------------------------------------------------------
                                   1264 ; external ram data
                                   1265 ;--------------------------------------------------------
                                   1266 	.area XSEG    (XDATA)
                                   1267 ;--------------------------------------------------------
                                   1268 ; absolute external ram data
                                   1269 ;--------------------------------------------------------
                                   1270 	.area XABS    (ABS,XDATA)
                                   1271 ;--------------------------------------------------------
                                   1272 ; external initialized ram data
                                   1273 ;--------------------------------------------------------
                                   1274 	.area XISEG   (XDATA)
                                   1275 	.area HOME    (CODE)
                                   1276 	.area GSINIT0 (CODE)
                                   1277 	.area GSINIT1 (CODE)
                                   1278 	.area GSINIT2 (CODE)
                                   1279 	.area GSINIT3 (CODE)
                                   1280 	.area GSINIT4 (CODE)
                                   1281 	.area GSINIT5 (CODE)
                                   1282 	.area GSINIT  (CODE)
                                   1283 	.area GSFINAL (CODE)
                                   1284 	.area CSEG    (CODE)
                                   1285 ;--------------------------------------------------------
                                   1286 ; interrupt vector 
                                   1287 ;--------------------------------------------------------
                                   1288 	.area HOME    (CODE)
      000000                       1289 __interrupt_vect:
      000000 02 00 31         [24] 1290 	ljmp	__sdcc_gsinit_startup
      000003 32               [24] 1291 	reti
      000004                       1292 	.ds	7
      00000B 32               [24] 1293 	reti
      00000C                       1294 	.ds	7
      000013 32               [24] 1295 	reti
      000014                       1296 	.ds	7
      00001B 02 06 CD         [24] 1297 	ljmp	_int_tc1
      00001E                       1298 	.ds	5
      000023 02 02 51         [24] 1299 	ljmp	_int_serial
      000026                       1300 	.ds	5
      00002B 02 04 B4         [24] 1301 	ljmp	_isr_timer2
                                   1302 ;--------------------------------------------------------
                                   1303 ; global & static initialisations
                                   1304 ;--------------------------------------------------------
                                   1305 	.area HOME    (CODE)
                                   1306 	.area GSINIT  (CODE)
                                   1307 	.area GSFINAL (CODE)
                                   1308 	.area GSINIT  (CODE)
                                   1309 	.globl __sdcc_gsinit_startup
                                   1310 	.globl __sdcc_program_startup
                                   1311 	.globl __start__stack
                                   1312 	.globl __mcs51_genXINIT
                                   1313 	.globl __mcs51_genXRAMCLEAR
                                   1314 	.globl __mcs51_genRAMCLEAR
                           000000  1315 	C$p3main.c$22$1$64 ==.
                                   1316 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:22: unsigned char estado = 0;  
      00008A 75 09 00         [24] 1317 	mov	_estado,#0x00
                           000003  1318 	C$p3main.c$25$1$64 ==.
                                   1319 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:25: volatile float counter = 0;
      00008D E4               [12] 1320 	clr	a
      00008E F5 0A            [12] 1321 	mov	_counter,a
      000090 F5 0B            [12] 1322 	mov	(_counter + 1),a
      000092 F5 0C            [12] 1323 	mov	(_counter + 2),a
      000094 F5 0D            [12] 1324 	mov	(_counter + 3),a
                                   1325 	.area GSFINAL (CODE)
      000096 02 00 2E         [24] 1326 	ljmp	__sdcc_program_startup
                                   1327 ;--------------------------------------------------------
                                   1328 ; Home
                                   1329 ;--------------------------------------------------------
                                   1330 	.area HOME    (CODE)
                                   1331 	.area HOME    (CODE)
      00002E                       1332 __sdcc_program_startup:
      00002E 02 01 63         [24] 1333 	ljmp	_main
                                   1334 ;	return from main will return to caller
                                   1335 ;--------------------------------------------------------
                                   1336 ; code
                                   1337 ;--------------------------------------------------------
                                   1338 	.area CSEG    (CODE)
                                   1339 ;------------------------------------------------------------
                                   1340 ;Allocation info for local variables in function 'Reset_Sources_Init'
                                   1341 ;------------------------------------------------------------
                           000000  1342 	G$Reset_Sources_Init$0$0 ==.
                           000000  1343 	C$config.c$10$0$0 ==.
                                   1344 ;	Z:\9semestre\micap\micap-master\p3\/config.c:10: void Reset_Sources_Init()
                                   1345 ;	-----------------------------------------
                                   1346 ;	 function Reset_Sources_Init
                                   1347 ;	-----------------------------------------
      000099                       1348 _Reset_Sources_Init:
                           000007  1349 	ar7 = 0x07
                           000006  1350 	ar6 = 0x06
                           000005  1351 	ar5 = 0x05
                           000004  1352 	ar4 = 0x04
                           000003  1353 	ar3 = 0x03
                           000002  1354 	ar2 = 0x02
                           000001  1355 	ar1 = 0x01
                           000000  1356 	ar0 = 0x00
                           000000  1357 	C$config.c$12$1$14 ==.
                                   1358 ;	Z:\9semestre\micap\micap-master\p3\/config.c:12: WDTCN     = 0xDE;
      000099 75 FF DE         [24] 1359 	mov	_WDTCN,#0xde
                           000003  1360 	C$config.c$13$1$14 ==.
                                   1361 ;	Z:\9semestre\micap\micap-master\p3\/config.c:13: WDTCN     = 0xAD;
      00009C 75 FF AD         [24] 1362 	mov	_WDTCN,#0xad
                           000006  1363 	C$config.c$14$1$14 ==.
                           000006  1364 	XG$Reset_Sources_Init$0$0 ==.
      00009F 22               [24] 1365 	ret
                                   1366 ;------------------------------------------------------------
                                   1367 ;Allocation info for local variables in function 'Timer_Init'
                                   1368 ;------------------------------------------------------------
                           000007  1369 	G$Timer_Init$0$0 ==.
                           000007  1370 	C$config.c$16$1$14 ==.
                                   1371 ;	Z:\9semestre\micap\micap-master\p3\/config.c:16: void Timer_Init()
                                   1372 ;	-----------------------------------------
                                   1373 ;	 function Timer_Init
                                   1374 ;	-----------------------------------------
      0000A0                       1375 _Timer_Init:
                           000007  1376 	C$config.c$18$1$15 ==.
                                   1377 ;	Z:\9semestre\micap\micap-master\p3\/config.c:18: SFRPAGE   = TIMER01_PAGE;
      0000A0 75 84 00         [24] 1378 	mov	_SFRPAGE,#0x00
                           00000A  1379 	C$config.c$19$1$15 ==.
                                   1380 ;	Z:\9semestre\micap\micap-master\p3\/config.c:19: TCON      = 0x05;
      0000A3 75 88 05         [24] 1381 	mov	_TCON,#0x05
                           00000D  1382 	C$config.c$20$1$15 ==.
                                   1383 ;	Z:\9semestre\micap\micap-master\p3\/config.c:20: TMOD      = 0x91;
      0000A6 75 89 91         [24] 1384 	mov	_TMOD,#0x91
                           000010  1385 	C$config.c$21$1$15 ==.
                                   1386 ;	Z:\9semestre\micap\micap-master\p3\/config.c:21: CKCON     = 0x18;
      0000A9 75 8E 18         [24] 1387 	mov	_CKCON,#0x18
                           000013  1388 	C$config.c$22$1$15 ==.
                                   1389 ;	Z:\9semestre\micap\micap-master\p3\/config.c:22: SFRPAGE   = TMR2_PAGE;
      0000AC 75 84 00         [24] 1390 	mov	_SFRPAGE,#0x00
                           000016  1391 	C$config.c$23$1$15 ==.
                                   1392 ;	Z:\9semestre\micap\micap-master\p3\/config.c:23: TMR2CN    = 0x04;
      0000AF 75 C8 04         [24] 1393 	mov	_TMR2CN,#0x04
                           000019  1394 	C$config.c$24$1$15 ==.
                                   1395 ;	Z:\9semestre\micap\micap-master\p3\/config.c:24: TMR2CF    = 0x08;
      0000B2 75 C9 08         [24] 1396 	mov	_TMR2CF,#0x08
                           00001C  1397 	C$config.c$25$1$15 ==.
                                   1398 ;	Z:\9semestre\micap\micap-master\p3\/config.c:25: RCAP2L    = 0xDC;
      0000B5 75 CA DC         [24] 1399 	mov	_RCAP2L,#0xdc
                           00001F  1400 	C$config.c$26$1$15 ==.
                                   1401 ;	Z:\9semestre\micap\micap-master\p3\/config.c:26: RCAP2H    = 0x0B;
      0000B8 75 CB 0B         [24] 1402 	mov	_RCAP2H,#0x0b
                           000022  1403 	C$config.c$27$1$15 ==.
                                   1404 ;	Z:\9semestre\micap\micap-master\p3\/config.c:27: TMR2L     = 0xDC;
      0000BB 75 CC DC         [24] 1405 	mov	_TMR2L,#0xdc
                           000025  1406 	C$config.c$28$1$15 ==.
                                   1407 ;	Z:\9semestre\micap\micap-master\p3\/config.c:28: TMR2H     = 0x0B;
      0000BE 75 CD 0B         [24] 1408 	mov	_TMR2H,#0x0b
                           000028  1409 	C$config.c$29$1$15 ==.
                                   1410 ;	Z:\9semestre\micap\micap-master\p3\/config.c:29: SFRPAGE   = TMR3_PAGE;
      0000C1 75 84 01         [24] 1411 	mov	_SFRPAGE,#0x01
                           00002B  1412 	C$config.c$30$1$15 ==.
                                   1413 ;	Z:\9semestre\micap\micap-master\p3\/config.c:30: TMR3CN    = 0x04;
      0000C4 75 C8 04         [24] 1414 	mov	_TMR3CN,#0x04
                           00002E  1415 	C$config.c$31$1$15 ==.
                                   1416 ;	Z:\9semestre\micap\micap-master\p3\/config.c:31: TMR3CF    = 0x08;
      0000C7 75 C9 08         [24] 1417 	mov	_TMR3CF,#0x08
                           000031  1418 	C$config.c$32$1$15 ==.
                                   1419 ;	Z:\9semestre\micap\micap-master\p3\/config.c:32: RCAP3L    = 0x5D;
      0000CA 75 CA 5D         [24] 1420 	mov	_RCAP3L,#0x5d
                           000034  1421 	C$config.c$33$1$15 ==.
                                   1422 ;	Z:\9semestre\micap\micap-master\p3\/config.c:33: RCAP3H    = 0xFF;
      0000CD 75 CB FF         [24] 1423 	mov	_RCAP3H,#0xff
                           000037  1424 	C$config.c$34$1$15 ==.
                           000037  1425 	XG$Timer_Init$0$0 ==.
      0000D0 22               [24] 1426 	ret
                                   1427 ;------------------------------------------------------------
                                   1428 ;Allocation info for local variables in function 'PCA_Init'
                                   1429 ;------------------------------------------------------------
                           000038  1430 	G$PCA_Init$0$0 ==.
                           000038  1431 	C$config.c$36$1$15 ==.
                                   1432 ;	Z:\9semestre\micap\micap-master\p3\/config.c:36: void PCA_Init()
                                   1433 ;	-----------------------------------------
                                   1434 ;	 function PCA_Init
                                   1435 ;	-----------------------------------------
      0000D1                       1436 _PCA_Init:
                           000038  1437 	C$config.c$38$1$16 ==.
                                   1438 ;	Z:\9semestre\micap\micap-master\p3\/config.c:38: SFRPAGE   = PCA0_PAGE;
      0000D1 75 84 00         [24] 1439 	mov	_SFRPAGE,#0x00
                           00003B  1440 	C$config.c$39$1$16 ==.
                                   1441 ;	Z:\9semestre\micap\micap-master\p3\/config.c:39: PCA0CN    = 0x40;
      0000D4 75 D8 40         [24] 1442 	mov	_PCA0CN,#0x40
                           00003E  1443 	C$config.c$40$1$16 ==.
                                   1444 ;	Z:\9semestre\micap\micap-master\p3\/config.c:40: PCA0CPM0  = 0x42;
      0000D7 75 DA 42         [24] 1445 	mov	_PCA0CPM0,#0x42
                           000041  1446 	C$config.c$41$1$16 ==.
                           000041  1447 	XG$PCA_Init$0$0 ==.
      0000DA 22               [24] 1448 	ret
                                   1449 ;------------------------------------------------------------
                                   1450 ;Allocation info for local variables in function 'UART_Init'
                                   1451 ;------------------------------------------------------------
                           000042  1452 	G$UART_Init$0$0 ==.
                           000042  1453 	C$config.c$43$1$16 ==.
                                   1454 ;	Z:\9semestre\micap\micap-master\p3\/config.c:43: void UART_Init()
                                   1455 ;	-----------------------------------------
                                   1456 ;	 function UART_Init
                                   1457 ;	-----------------------------------------
      0000DB                       1458 _UART_Init:
                           000042  1459 	C$config.c$45$1$17 ==.
                                   1460 ;	Z:\9semestre\micap\micap-master\p3\/config.c:45: SFRPAGE   = UART0_PAGE;
      0000DB 75 84 00         [24] 1461 	mov	_SFRPAGE,#0x00
                           000045  1462 	C$config.c$46$1$17 ==.
                                   1463 ;	Z:\9semestre\micap\micap-master\p3\/config.c:46: SCON0     = 0x50;
      0000DE 75 98 50         [24] 1464 	mov	_SCON0,#0x50
                           000048  1465 	C$config.c$47$1$17 ==.
                                   1466 ;	Z:\9semestre\micap\micap-master\p3\/config.c:47: SSTA0     = 0x0A;
      0000E1 75 91 0A         [24] 1467 	mov	_SSTA0,#0x0a
                           00004B  1468 	C$config.c$48$1$17 ==.
                           00004B  1469 	XG$UART_Init$0$0 ==.
      0000E4 22               [24] 1470 	ret
                                   1471 ;------------------------------------------------------------
                                   1472 ;Allocation info for local variables in function 'SPI_Init'
                                   1473 ;------------------------------------------------------------
                           00004C  1474 	G$SPI_Init$0$0 ==.
                           00004C  1475 	C$config.c$50$1$17 ==.
                                   1476 ;	Z:\9semestre\micap\micap-master\p3\/config.c:50: void SPI_Init()
                                   1477 ;	-----------------------------------------
                                   1478 ;	 function SPI_Init
                                   1479 ;	-----------------------------------------
      0000E5                       1480 _SPI_Init:
                           00004C  1481 	C$config.c$52$1$18 ==.
                                   1482 ;	Z:\9semestre\micap\micap-master\p3\/config.c:52: SFRPAGE   = SPI0_PAGE;
      0000E5 75 84 00         [24] 1483 	mov	_SFRPAGE,#0x00
                           00004F  1484 	C$config.c$53$1$18 ==.
                                   1485 ;	Z:\9semestre\micap\micap-master\p3\/config.c:53: SPI0CFG   = 0x40;
      0000E8 75 9A 40         [24] 1486 	mov	_SPI0CFG,#0x40
                           000052  1487 	C$config.c$54$1$18 ==.
                                   1488 ;	Z:\9semestre\micap\micap-master\p3\/config.c:54: SPI0CN    = 0x01;
      0000EB 75 F8 01         [24] 1489 	mov	_SPI0CN,#0x01
                           000055  1490 	C$config.c$55$1$18 ==.
                                   1491 ;	Z:\9semestre\micap\micap-master\p3\/config.c:55: SPI0CKR   = 0x7C;
      0000EE 75 9D 7C         [24] 1492 	mov	_SPI0CKR,#0x7c
                           000058  1493 	C$config.c$56$1$18 ==.
                           000058  1494 	XG$SPI_Init$0$0 ==.
      0000F1 22               [24] 1495 	ret
                                   1496 ;------------------------------------------------------------
                                   1497 ;Allocation info for local variables in function 'ADC_Init'
                                   1498 ;------------------------------------------------------------
                           000059  1499 	G$ADC_Init$0$0 ==.
                           000059  1500 	C$config.c$58$1$18 ==.
                                   1501 ;	Z:\9semestre\micap\micap-master\p3\/config.c:58: void ADC_Init()
                                   1502 ;	-----------------------------------------
                                   1503 ;	 function ADC_Init
                                   1504 ;	-----------------------------------------
      0000F2                       1505 _ADC_Init:
                           000059  1506 	C$config.c$60$1$19 ==.
                                   1507 ;	Z:\9semestre\micap\micap-master\p3\/config.c:60: SFRPAGE   = ADC0_PAGE;
      0000F2 75 84 00         [24] 1508 	mov	_SFRPAGE,#0x00
                           00005C  1509 	C$config.c$61$1$19 ==.
                                   1510 ;	Z:\9semestre\micap\micap-master\p3\/config.c:61: ADC0CN    = 0x80;
      0000F5 75 E8 80         [24] 1511 	mov	_ADC0CN,#0x80
                           00005F  1512 	C$config.c$62$1$19 ==.
                           00005F  1513 	XG$ADC_Init$0$0 ==.
      0000F8 22               [24] 1514 	ret
                                   1515 ;------------------------------------------------------------
                                   1516 ;Allocation info for local variables in function 'DAC_Init'
                                   1517 ;------------------------------------------------------------
                           000060  1518 	G$DAC_Init$0$0 ==.
                           000060  1519 	C$config.c$64$1$19 ==.
                                   1520 ;	Z:\9semestre\micap\micap-master\p3\/config.c:64: void DAC_Init()
                                   1521 ;	-----------------------------------------
                                   1522 ;	 function DAC_Init
                                   1523 ;	-----------------------------------------
      0000F9                       1524 _DAC_Init:
                           000060  1525 	C$config.c$66$1$20 ==.
                                   1526 ;	Z:\9semestre\micap\micap-master\p3\/config.c:66: SFRPAGE   = DAC0_PAGE;
      0000F9 75 84 00         [24] 1527 	mov	_SFRPAGE,#0x00
                           000063  1528 	C$config.c$67$1$20 ==.
                                   1529 ;	Z:\9semestre\micap\micap-master\p3\/config.c:67: DAC0CN    = 0x80;
      0000FC 75 D4 80         [24] 1530 	mov	_DAC0CN,#0x80
                           000066  1531 	C$config.c$68$1$20 ==.
                           000066  1532 	XG$DAC_Init$0$0 ==.
      0000FF 22               [24] 1533 	ret
                                   1534 ;------------------------------------------------------------
                                   1535 ;Allocation info for local variables in function 'Voltage_Reference_Init'
                                   1536 ;------------------------------------------------------------
                           000067  1537 	G$Voltage_Reference_Init$0$0 ==.
                           000067  1538 	C$config.c$70$1$20 ==.
                                   1539 ;	Z:\9semestre\micap\micap-master\p3\/config.c:70: void Voltage_Reference_Init()
                                   1540 ;	-----------------------------------------
                                   1541 ;	 function Voltage_Reference_Init
                                   1542 ;	-----------------------------------------
      000100                       1543 _Voltage_Reference_Init:
                           000067  1544 	C$config.c$72$1$21 ==.
                                   1545 ;	Z:\9semestre\micap\micap-master\p3\/config.c:72: SFRPAGE   = ADC0_PAGE;
      000100 75 84 00         [24] 1546 	mov	_SFRPAGE,#0x00
                           00006A  1547 	C$config.c$73$1$21 ==.
                                   1548 ;	Z:\9semestre\micap\micap-master\p3\/config.c:73: REF0CN    = 0x03;
      000103 75 D1 03         [24] 1549 	mov	_REF0CN,#0x03
                           00006D  1550 	C$config.c$74$1$21 ==.
                           00006D  1551 	XG$Voltage_Reference_Init$0$0 ==.
      000106 22               [24] 1552 	ret
                                   1553 ;------------------------------------------------------------
                                   1554 ;Allocation info for local variables in function 'Port_IO_Init'
                                   1555 ;------------------------------------------------------------
                           00006E  1556 	G$Port_IO_Init$0$0 ==.
                           00006E  1557 	C$config.c$76$1$21 ==.
                                   1558 ;	Z:\9semestre\micap\micap-master\p3\/config.c:76: void Port_IO_Init()
                                   1559 ;	-----------------------------------------
                                   1560 ;	 function Port_IO_Init
                                   1561 ;	-----------------------------------------
      000107                       1562 _Port_IO_Init:
                           00006E  1563 	C$config.c$114$1$22 ==.
                                   1564 ;	Z:\9semestre\micap\micap-master\p3\/config.c:114: SFRPAGE   = CONFIG_PAGE;
      000107 75 84 0F         [24] 1565 	mov	_SFRPAGE,#0x0f
                           000071  1566 	C$config.c$115$1$22 ==.
                                   1567 ;	Z:\9semestre\micap\micap-master\p3\/config.c:115: P0MDOUT   = 0xB5;
      00010A 75 A4 B5         [24] 1568 	mov	_P0MDOUT,#0xb5
                           000074  1569 	C$config.c$116$1$22 ==.
                                   1570 ;	Z:\9semestre\micap\micap-master\p3\/config.c:116: XBR0      = 0x0E;
      00010D 75 E1 0E         [24] 1571 	mov	_XBR0,#0x0e
                           000077  1572 	C$config.c$117$1$22 ==.
                                   1573 ;	Z:\9semestre\micap\micap-master\p3\/config.c:117: XBR1      = 0x10;
      000110 75 E2 10         [24] 1574 	mov	_XBR1,#0x10
                           00007A  1575 	C$config.c$118$1$22 ==.
                                   1576 ;	Z:\9semestre\micap\micap-master\p3\/config.c:118: XBR2      = 0x40;
      000113 75 E3 40         [24] 1577 	mov	_XBR2,#0x40
                           00007D  1578 	C$config.c$119$1$22 ==.
                           00007D  1579 	XG$Port_IO_Init$0$0 ==.
      000116 22               [24] 1580 	ret
                                   1581 ;------------------------------------------------------------
                                   1582 ;Allocation info for local variables in function 'Oscillator_Init'
                                   1583 ;------------------------------------------------------------
                                   1584 ;i                         Allocated to registers r6 r7 
                                   1585 ;------------------------------------------------------------
                           00007E  1586 	G$Oscillator_Init$0$0 ==.
                           00007E  1587 	C$config.c$121$1$22 ==.
                                   1588 ;	Z:\9semestre\micap\micap-master\p3\/config.c:121: void Oscillator_Init()
                                   1589 ;	-----------------------------------------
                                   1590 ;	 function Oscillator_Init
                                   1591 ;	-----------------------------------------
      000117                       1592 _Oscillator_Init:
                           00007E  1593 	C$config.c$124$1$23 ==.
                                   1594 ;	Z:\9semestre\micap\micap-master\p3\/config.c:124: SFRPAGE   = CONFIG_PAGE;
      000117 75 84 0F         [24] 1595 	mov	_SFRPAGE,#0x0f
                           000081  1596 	C$config.c$125$1$23 ==.
                                   1597 ;	Z:\9semestre\micap\micap-master\p3\/config.c:125: OSCXCN    = 0x67;
      00011A 75 8C 67         [24] 1598 	mov	_OSCXCN,#0x67
                           000084  1599 	C$config.c$126$1$23 ==.
                                   1600 ;	Z:\9semestre\micap\micap-master\p3\/config.c:126: for (i = 0; i < 3000; i++);  // Wait 1ms for initialization
      00011D 7E B8            [12] 1601 	mov	r6,#0xb8
      00011F 7F 0B            [12] 1602 	mov	r7,#0x0b
      000121                       1603 00107$:
      000121 EE               [12] 1604 	mov	a,r6
      000122 24 FF            [12] 1605 	add	a,#0xff
      000124 FC               [12] 1606 	mov	r4,a
      000125 EF               [12] 1607 	mov	a,r7
      000126 34 FF            [12] 1608 	addc	a,#0xff
      000128 FD               [12] 1609 	mov	r5,a
      000129 8C 06            [24] 1610 	mov	ar6,r4
      00012B 8D 07            [24] 1611 	mov	ar7,r5
      00012D EC               [12] 1612 	mov	a,r4
      00012E 4D               [12] 1613 	orl	a,r5
      00012F 70 F0            [24] 1614 	jnz	00107$
                           000098  1615 	C$config.c$127$1$23 ==.
                                   1616 ;	Z:\9semestre\micap\micap-master\p3\/config.c:127: while ((OSCXCN & 0x80) == 0);
      000131                       1617 00102$:
      000131 E5 8C            [12] 1618 	mov	a,_OSCXCN
      000133 30 E7 FB         [24] 1619 	jnb	acc.7,00102$
                           00009D  1620 	C$config.c$128$1$23 ==.
                                   1621 ;	Z:\9semestre\micap\micap-master\p3\/config.c:128: CLKSEL    = 0x01;
      000136 75 97 01         [24] 1622 	mov	_CLKSEL,#0x01
                           0000A0  1623 	C$config.c$129$1$23 ==.
                           0000A0  1624 	XG$Oscillator_Init$0$0 ==.
      000139 22               [24] 1625 	ret
                                   1626 ;------------------------------------------------------------
                                   1627 ;Allocation info for local variables in function 'Interrupts_Init'
                                   1628 ;------------------------------------------------------------
                           0000A1  1629 	G$Interrupts_Init$0$0 ==.
                           0000A1  1630 	C$config.c$131$1$23 ==.
                                   1631 ;	Z:\9semestre\micap\micap-master\p3\/config.c:131: void Interrupts_Init()
                                   1632 ;	-----------------------------------------
                                   1633 ;	 function Interrupts_Init
                                   1634 ;	-----------------------------------------
      00013A                       1635 _Interrupts_Init:
                           0000A1  1636 	C$config.c$133$1$24 ==.
                                   1637 ;	Z:\9semestre\micap\micap-master\p3\/config.c:133: IE        = 0xB8;
      00013A 75 A8 B8         [24] 1638 	mov	_IE,#0xb8
                           0000A4  1639 	C$config.c$134$1$24 ==.
                                   1640 ;	Z:\9semestre\micap\micap-master\p3\/config.c:134: IP        = 0xE8;
      00013D 75 B8 E8         [24] 1641 	mov	_IP,#0xe8
                           0000A7  1642 	C$config.c$135$1$24 ==.
                           0000A7  1643 	XG$Interrupts_Init$0$0 ==.
      000140 22               [24] 1644 	ret
                                   1645 ;------------------------------------------------------------
                                   1646 ;Allocation info for local variables in function 'Init_Device'
                                   1647 ;------------------------------------------------------------
                           0000A8  1648 	G$Init_Device$0$0 ==.
                           0000A8  1649 	C$config.c$139$1$24 ==.
                                   1650 ;	Z:\9semestre\micap\micap-master\p3\/config.c:139: void Init_Device(void)
                                   1651 ;	-----------------------------------------
                                   1652 ;	 function Init_Device
                                   1653 ;	-----------------------------------------
      000141                       1654 _Init_Device:
                           0000A8  1655 	C$config.c$141$1$26 ==.
                                   1656 ;	Z:\9semestre\micap\micap-master\p3\/config.c:141: Reset_Sources_Init();
      000141 12 00 99         [24] 1657 	lcall	_Reset_Sources_Init
                           0000AB  1658 	C$config.c$142$1$26 ==.
                                   1659 ;	Z:\9semestre\micap\micap-master\p3\/config.c:142: Timer_Init();
      000144 12 00 A0         [24] 1660 	lcall	_Timer_Init
                           0000AE  1661 	C$config.c$143$1$26 ==.
                                   1662 ;	Z:\9semestre\micap\micap-master\p3\/config.c:143: PCA_Init();
      000147 12 00 D1         [24] 1663 	lcall	_PCA_Init
                           0000B1  1664 	C$config.c$144$1$26 ==.
                                   1665 ;	Z:\9semestre\micap\micap-master\p3\/config.c:144: UART_Init();
      00014A 12 00 DB         [24] 1666 	lcall	_UART_Init
                           0000B4  1667 	C$config.c$145$1$26 ==.
                                   1668 ;	Z:\9semestre\micap\micap-master\p3\/config.c:145: SPI_Init();
      00014D 12 00 E5         [24] 1669 	lcall	_SPI_Init
                           0000B7  1670 	C$config.c$146$1$26 ==.
                                   1671 ;	Z:\9semestre\micap\micap-master\p3\/config.c:146: ADC_Init();
      000150 12 00 F2         [24] 1672 	lcall	_ADC_Init
                           0000BA  1673 	C$config.c$147$1$26 ==.
                                   1674 ;	Z:\9semestre\micap\micap-master\p3\/config.c:147: DAC_Init();
      000153 12 00 F9         [24] 1675 	lcall	_DAC_Init
                           0000BD  1676 	C$config.c$148$1$26 ==.
                                   1677 ;	Z:\9semestre\micap\micap-master\p3\/config.c:148: Voltage_Reference_Init();
      000156 12 01 00         [24] 1678 	lcall	_Voltage_Reference_Init
                           0000C0  1679 	C$config.c$149$1$26 ==.
                                   1680 ;	Z:\9semestre\micap\micap-master\p3\/config.c:149: Port_IO_Init();
      000159 12 01 07         [24] 1681 	lcall	_Port_IO_Init
                           0000C3  1682 	C$config.c$150$1$26 ==.
                                   1683 ;	Z:\9semestre\micap\micap-master\p3\/config.c:150: Oscillator_Init();
      00015C 12 01 17         [24] 1684 	lcall	_Oscillator_Init
                           0000C6  1685 	C$config.c$151$1$26 ==.
                                   1686 ;	Z:\9semestre\micap\micap-master\p3\/config.c:151: Interrupts_Init();
      00015F 12 01 3A         [24] 1687 	lcall	_Interrupts_Init
                           0000C9  1688 	C$config.c$152$1$26 ==.
                           0000C9  1689 	XG$Init_Device$0$0 ==.
      000162 22               [24] 1690 	ret
                                   1691 ;------------------------------------------------------------
                                   1692 ;Allocation info for local variables in function 'main'
                                   1693 ;------------------------------------------------------------
                           0000CA  1694 	G$main$0$0 ==.
                           0000CA  1695 	C$p3main.c$41$1$26 ==.
                                   1696 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:41: int main() {
                                   1697 ;	-----------------------------------------
                                   1698 ;	 function main
                                   1699 ;	-----------------------------------------
      000163                       1700 _main:
                           0000CA  1701 	C$p3main.c$43$1$34 ==.
                                   1702 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:43: Init_Device();
      000163 12 01 41         [24] 1703 	lcall	_Init_Device
                           0000CD  1704 	C$p3main.c$44$1$34 ==.
                                   1705 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:44: SFRPAGE = LEGACY_PAGE;
      000166 75 84 00         [24] 1706 	mov	_SFRPAGE,#0x00
                           0000D0  1707 	C$p3main.c$46$1$34 ==.
                                   1708 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:46: TMR2H = 0x0B;
      000169 75 CD 0B         [24] 1709 	mov	_TMR2H,#0x0b
                           0000D3  1710 	C$p3main.c$47$1$34 ==.
                                   1711 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:47: TMR2L = 0xDC;
      00016C 75 CC DC         [24] 1712 	mov	_TMR2L,#0xdc
                           0000D6  1713 	C$p3main.c$48$1$34 ==.
                                   1714 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:48: RCAP2H = 0x0B; 
      00016F 75 CB 0B         [24] 1715 	mov	_RCAP2H,#0x0b
                           0000D9  1716 	C$p3main.c$49$1$34 ==.
                                   1717 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:49: RCAP2L = 0xDC;
      000172 75 CA DC         [24] 1718 	mov	_RCAP2L,#0xdc
                           0000DC  1719 	C$p3main.c$50$1$34 ==.
                                   1720 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:50: TR2 = 1;
      000175 D2 CA            [12] 1721 	setb	_TR2
                           0000DE  1722 	C$p3main.c$52$1$34 ==.
                                   1723 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:52: P3 = 0xff;
      000177 75 B0 FF         [24] 1724 	mov	_P3,#0xff
                           0000E1  1725 	C$p3main.c$54$1$34 ==.
                                   1726 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:54: printf_fast_f("Iniciando firmware.\n");
      00017A 74 43            [12] 1727 	mov	a,#___str_0
      00017C C0 E0            [24] 1728 	push	acc
      00017E 74 10            [12] 1729 	mov	a,#(___str_0 >> 8)
      000180 C0 E0            [24] 1730 	push	acc
      000182 12 07 F1         [24] 1731 	lcall	_printf_fast_f
      000185 15 81            [12] 1732 	dec	sp
      000187 15 81            [12] 1733 	dec	sp
                           0000F0  1734 	C$p3main.c$56$1$34 ==.
                                   1735 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:56: while(1){
      000189                       1736 00107$:
                           0000F0  1737 	C$p3main.c$58$2$35 ==.
                                   1738 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:58: switch(tecla) {
      000189 74 01            [12] 1739 	mov	a,#0x01
      00018B B5 08 02         [24] 1740 	cjne	a,_tecla,00123$
      00018E 80 11            [24] 1741 	sjmp	00101$
      000190                       1742 00123$:
      000190 74 02            [12] 1743 	mov	a,#0x02
      000192 B5 08 02         [24] 1744 	cjne	a,_tecla,00124$
      000195 80 0F            [24] 1745 	sjmp	00102$
      000197                       1746 00124$:
      000197 74 03            [12] 1747 	mov	a,#0x03
      000199 B5 08 03         [24] 1748 	cjne	a,_tecla,00125$
      00019C 02 02 1C         [24] 1749 	ljmp	00103$
      00019F                       1750 00125$:
                           000106  1751 	C$p3main.c$61$3$36 ==.
                                   1752 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:61: case 1:
      00019F 80 E8            [24] 1753 	sjmp	00107$
      0001A1                       1754 00101$:
                           000108  1755 	C$p3main.c$62$3$36 ==.
                                   1756 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:62: le_LM35();
      0001A1 12 06 60         [24] 1757 	lcall	_le_LM35
                           00010B  1758 	C$p3main.c$63$3$36 ==.
                                   1759 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:63: break;
                           00010B  1760 	C$p3main.c$66$3$36 ==.
                                   1761 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:66: case 2:
      0001A4 80 E3            [24] 1762 	sjmp	00107$
      0001A6                       1763 00102$:
                           00010D  1764 	C$p3main.c$67$3$36 ==.
                                   1765 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:67: printf_fast_f("Tensao aplicada a placa peltier: %3.1fV\n", ((float)le_ADC0(AIN0_1, G1) * 0.00059326171875 / 1) / 0.1803);
      0001A6 75 15 00         [24] 1766 	mov	_le_ADC0_PARM_2,#0x00
      0001A9 75 82 01         [24] 1767 	mov	dpl,#0x01
      0001AC 12 06 3D         [24] 1768 	lcall	_le_ADC0
      0001AF 12 0E D8         [24] 1769 	lcall	___uint2fs
      0001B2 AC 82            [24] 1770 	mov	r4,dpl
      0001B4 AD 83            [24] 1771 	mov	r5,dph
      0001B6 AE F0            [24] 1772 	mov	r6,b
      0001B8 FF               [12] 1773 	mov	r7,a
      0001B9 C0 04            [24] 1774 	push	ar4
      0001BB C0 05            [24] 1775 	push	ar5
      0001BD C0 06            [24] 1776 	push	ar6
      0001BF C0 07            [24] 1777 	push	ar7
      0001C1 90 85 1F         [24] 1778 	mov	dptr,#0x851f
      0001C4 75 F0 1B         [24] 1779 	mov	b,#0x1b
      0001C7 74 3A            [12] 1780 	mov	a,#0x3a
      0001C9 12 0C 72         [24] 1781 	lcall	___fsmul
      0001CC AC 82            [24] 1782 	mov	r4,dpl
      0001CE AD 83            [24] 1783 	mov	r5,dph
      0001D0 AE F0            [24] 1784 	mov	r6,b
      0001D2 FF               [12] 1785 	mov	r7,a
      0001D3 E5 81            [12] 1786 	mov	a,sp
      0001D5 24 FC            [12] 1787 	add	a,#0xfc
      0001D7 F5 81            [12] 1788 	mov	sp,a
      0001D9 74 90            [12] 1789 	mov	a,#0x90
      0001DB C0 E0            [24] 1790 	push	acc
      0001DD 74 A0            [12] 1791 	mov	a,#0xa0
      0001DF C0 E0            [24] 1792 	push	acc
      0001E1 74 38            [12] 1793 	mov	a,#0x38
      0001E3 C0 E0            [24] 1794 	push	acc
      0001E5 74 3E            [12] 1795 	mov	a,#0x3e
      0001E7 C0 E0            [24] 1796 	push	acc
      0001E9 8C 82            [24] 1797 	mov	dpl,r4
      0001EB 8D 83            [24] 1798 	mov	dph,r5
      0001ED 8E F0            [24] 1799 	mov	b,r6
      0001EF EF               [12] 1800 	mov	a,r7
      0001F0 12 0F 4D         [24] 1801 	lcall	___fsdiv
      0001F3 AC 82            [24] 1802 	mov	r4,dpl
      0001F5 AD 83            [24] 1803 	mov	r5,dph
      0001F7 AE F0            [24] 1804 	mov	r6,b
      0001F9 FF               [12] 1805 	mov	r7,a
      0001FA E5 81            [12] 1806 	mov	a,sp
      0001FC 24 FC            [12] 1807 	add	a,#0xfc
      0001FE F5 81            [12] 1808 	mov	sp,a
      000200 C0 04            [24] 1809 	push	ar4
      000202 C0 05            [24] 1810 	push	ar5
      000204 C0 06            [24] 1811 	push	ar6
      000206 C0 07            [24] 1812 	push	ar7
      000208 74 58            [12] 1813 	mov	a,#___str_1
      00020A C0 E0            [24] 1814 	push	acc
      00020C 74 10            [12] 1815 	mov	a,#(___str_1 >> 8)
      00020E C0 E0            [24] 1816 	push	acc
      000210 12 07 F1         [24] 1817 	lcall	_printf_fast_f
      000213 E5 81            [12] 1818 	mov	a,sp
      000215 24 FA            [12] 1819 	add	a,#0xfa
      000217 F5 81            [12] 1820 	mov	sp,a
                           000180  1821 	C$p3main.c$68$3$36 ==.
                                   1822 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:68: break;
      000219 02 01 89         [24] 1823 	ljmp	00107$
                           000183  1824 	C$p3main.c$71$3$36 ==.
                                   1825 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:71: case 3:
      00021C                       1826 00103$:
                           000183  1827 	C$p3main.c$72$3$36 ==.
                                   1828 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:72: test_RAM_SPI();
      00021C 12 05 65         [24] 1829 	lcall	_test_RAM_SPI
                           000186  1830 	C$p3main.c$73$3$36 ==.
                                   1831 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:73: break;
      00021F 02 01 89         [24] 1832 	ljmp	00107$
                           000189  1833 	C$p3main.c$80$1$34 ==.
                                   1834 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:80: return 0;
                           000189  1835 	C$p3main.c$81$1$34 ==.
                           000189  1836 	XG$main$0$0 ==.
      000222 22               [24] 1837 	ret
                                   1838 ;------------------------------------------------------------
                                   1839 ;Allocation info for local variables in function 'delay_ms'
                                   1840 ;------------------------------------------------------------
                                   1841 ;t                         Allocated to registers r6 r7 
                                   1842 ;------------------------------------------------------------
                           00018A  1843 	G$delay_ms$0$0 ==.
                           00018A  1844 	C$p3main.c$83$1$34 ==.
                                   1845 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:83: void delay_ms(unsigned int t) __reentrant
                                   1846 ;	-----------------------------------------
                                   1847 ;	 function delay_ms
                                   1848 ;	-----------------------------------------
      000223                       1849 _delay_ms:
      000223 AE 82            [24] 1850 	mov	r6,dpl
      000225 AF 83            [24] 1851 	mov	r7,dph
                           00018E  1852 	C$p3main.c$85$1$38 ==.
                                   1853 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:85: TMOD |= 0x01;
      000227 43 89 01         [24] 1854 	orl	_TMOD,#0x01
                           000191  1855 	C$p3main.c$86$1$38 ==.
                                   1856 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:86: TMOD &= ~0x02; 
      00022A 53 89 FD         [24] 1857 	anl	_TMOD,#0xfd
                           000194  1858 	C$p3main.c$87$1$38 ==.
                                   1859 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:87: while(t>0)
      00022D                       1860 00104$:
      00022D EE               [12] 1861 	mov	a,r6
      00022E 4F               [12] 1862 	orl	a,r7
      00022F 60 16            [24] 1863 	jz	00107$
                           000198  1864 	C$p3main.c$89$2$39 ==.
                                   1865 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:89: TR0 = 0;
      000231 C2 8C            [12] 1866 	clr	_TR0
                           00019A  1867 	C$p3main.c$90$2$39 ==.
                                   1868 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:90: TF0 = 0;
      000233 C2 8D            [12] 1869 	clr	_TF0
                           00019C  1870 	C$p3main.c$91$2$39 ==.
                                   1871 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:91: TH0 = 0x9E; 
      000235 75 8C 9E         [24] 1872 	mov	_TH0,#0x9e
                           00019F  1873 	C$p3main.c$92$2$39 ==.
                                   1874 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:92: TL0 = 0x58;
      000238 75 8A 58         [24] 1875 	mov	_TL0,#0x58
                           0001A2  1876 	C$p3main.c$93$2$39 ==.
                                   1877 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:93: TR0 = 1;
      00023B D2 8C            [12] 1878 	setb	_TR0
                           0001A4  1879 	C$p3main.c$94$2$39 ==.
                                   1880 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:94: while(TF0 != 1);
      00023D                       1881 00101$:
      00023D 30 8D FD         [24] 1882 	jnb	_TF0,00101$
                           0001A7  1883 	C$p3main.c$95$2$39 ==.
                                   1884 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:95: t--;
      000240 1E               [12] 1885 	dec	r6
      000241 BE FF 01         [24] 1886 	cjne	r6,#0xff,00124$
      000244 1F               [12] 1887 	dec	r7
      000245                       1888 00124$:
      000245 80 E6            [24] 1889 	sjmp	00104$
      000247                       1890 00107$:
                           0001AE  1891 	C$p3main.c$97$1$38 ==.
                           0001AE  1892 	XG$delay_ms$0$0 ==.
      000247 22               [24] 1893 	ret
                                   1894 ;------------------------------------------------------------
                                   1895 ;Allocation info for local variables in function 'putchar'
                                   1896 ;------------------------------------------------------------
                                   1897 ;c                         Allocated to registers 
                                   1898 ;------------------------------------------------------------
                           0001AF  1899 	G$putchar$0$0 ==.
                           0001AF  1900 	C$p3main.c$100$1$38 ==.
                                   1901 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:100: void putchar (char c ) {
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function putchar
                                   1904 ;	-----------------------------------------
      000248                       1905 _putchar:
      000248 85 82 99         [24] 1906 	mov	_SBUF0,dpl
                           0001B2  1907 	C$p3main.c$102$1$41 ==.
                                   1908 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:102: while (TI0 == 0); 
      00024B                       1909 00101$:
                           0001B2  1910 	C$p3main.c$103$1$41 ==.
                                   1911 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:103: TI0 = 0;
      00024B 10 99 02         [24] 1912 	jbc	_TI0,00112$
      00024E 80 FB            [24] 1913 	sjmp	00101$
      000250                       1914 00112$:
                           0001B7  1915 	C$p3main.c$104$1$41 ==.
                           0001B7  1916 	XG$putchar$0$0 ==.
      000250 22               [24] 1917 	ret
                                   1918 ;------------------------------------------------------------
                                   1919 ;Allocation info for local variables in function 'int_serial'
                                   1920 ;------------------------------------------------------------
                           0001B8  1921 	G$int_serial$0$0 ==.
                           0001B8  1922 	C$p3main.c$108$1$41 ==.
                                   1923 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:108: void int_serial(void) __interrupt 4 {
                                   1924 ;	-----------------------------------------
                                   1925 ;	 function int_serial
                                   1926 ;	-----------------------------------------
      000251                       1927 _int_serial:
      000251 C0 21            [24] 1928 	push	bits
      000253 C0 E0            [24] 1929 	push	acc
      000255 C0 F0            [24] 1930 	push	b
      000257 C0 82            [24] 1931 	push	dpl
      000259 C0 83            [24] 1932 	push	dph
      00025B C0 07            [24] 1933 	push	(0+7)
      00025D C0 06            [24] 1934 	push	(0+6)
      00025F C0 05            [24] 1935 	push	(0+5)
      000261 C0 04            [24] 1936 	push	(0+4)
      000263 C0 03            [24] 1937 	push	(0+3)
      000265 C0 02            [24] 1938 	push	(0+2)
      000267 C0 01            [24] 1939 	push	(0+1)
      000269 C0 00            [24] 1940 	push	(0+0)
      00026B C0 D0            [24] 1941 	push	psw
      00026D 75 D0 00         [24] 1942 	mov	psw,#0x00
                           0001D7  1943 	C$p3main.c$109$1$43 ==.
                                   1944 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:109: if (RI0 == 1) {
      000270 20 98 03         [24] 1945 	jb	_RI0,00158$
      000273 02 04 70         [24] 1946 	ljmp	00120$
      000276                       1947 00158$:
                           0001DD  1948 	C$p3main.c$110$2$44 ==.
                                   1949 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:110: switch (SBUF0) {
      000276 AF 99            [24] 1950 	mov	r7,_SBUF0
      000278 BF 31 03         [24] 1951 	cjne	r7,#0x31,00159$
      00027B 02 03 EC         [24] 1952 	ljmp	00113$
      00027E                       1953 00159$:
      00027E BF 32 03         [24] 1954 	cjne	r7,#0x32,00160$
      000281 02 04 18         [24] 1955 	ljmp	00114$
      000284                       1956 00160$:
      000284 BF 33 03         [24] 1957 	cjne	r7,#0x33,00161$
      000287 02 04 44         [24] 1958 	ljmp	00115$
      00028A                       1959 00161$:
      00028A BF 61 03         [24] 1960 	cjne	r7,#0x61,00162$
      00028D 02 03 42         [24] 1961 	ljmp	00105$
      000290                       1962 00162$:
      000290 BF 64 03         [24] 1963 	cjne	r7,#0x64,00163$
      000293 02 03 34         [24] 1964 	ljmp	00102$
      000296                       1965 00163$:
      000296 BF 6D 02         [24] 1966 	cjne	r7,#0x6d,00164$
      000299 80 0F            [24] 1967 	sjmp	00101$
      00029B                       1968 00164$:
      00029B BF 70 03         [24] 1969 	cjne	r7,#0x70,00165$
      00029E 02 03 4E         [24] 1970 	ljmp	00108$
      0002A1                       1971 00165$:
      0002A1 BF 72 03         [24] 1972 	cjne	r7,#0x72,00166$
      0002A4 02 03 86         [24] 1973 	ljmp	00112$
      0002A7                       1974 00166$:
      0002A7 02 04 6E         [24] 1975 	ljmp	00117$
                           000211  1976 	C$p3main.c$112$3$45 ==.
                                   1977 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:112: case 'm':
      0002AA                       1978 00101$:
                           000211  1979 	C$p3main.c$113$3$45 ==.
                                   1980 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:113: printf_fast_f("\n MENU:\n");
      0002AA 74 81            [12] 1981 	mov	a,#___str_2
      0002AC C0 E0            [24] 1982 	push	acc
      0002AE 74 10            [12] 1983 	mov	a,#(___str_2 >> 8)
      0002B0 C0 E0            [24] 1984 	push	acc
      0002B2 12 07 F1         [24] 1985 	lcall	_printf_fast_f
      0002B5 15 81            [12] 1986 	dec	sp
      0002B7 15 81            [12] 1987 	dec	sp
                           000220  1988 	C$p3main.c$114$3$45 ==.
                                   1989 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:114: printf_fast_f("a: Aumenta RPM do motor.\n");
      0002B9 74 8A            [12] 1990 	mov	a,#___str_3
      0002BB C0 E0            [24] 1991 	push	acc
      0002BD 74 10            [12] 1992 	mov	a,#(___str_3 >> 8)
      0002BF C0 E0            [24] 1993 	push	acc
      0002C1 12 07 F1         [24] 1994 	lcall	_printf_fast_f
      0002C4 15 81            [12] 1995 	dec	sp
      0002C6 15 81            [12] 1996 	dec	sp
                           00022F  1997 	C$p3main.c$115$3$45 ==.
                                   1998 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:115: printf_fast_f("d: Diminui RPM do motor.\n");
      0002C8 74 A4            [12] 1999 	mov	a,#___str_4
      0002CA C0 E0            [24] 2000 	push	acc
      0002CC 74 10            [12] 2001 	mov	a,#(___str_4 >> 8)
      0002CE C0 E0            [24] 2002 	push	acc
      0002D0 12 07 F1         [24] 2003 	lcall	_printf_fast_f
      0002D3 15 81            [12] 2004 	dec	sp
      0002D5 15 81            [12] 2005 	dec	sp
                           00023E  2006 	C$p3main.c$116$3$45 ==.
                                   2007 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:116: printf_fast_f("p: Liga/desliga fonte de energia placa peltier.\n");
      0002D7 74 BE            [12] 2008 	mov	a,#___str_5
      0002D9 C0 E0            [24] 2009 	push	acc
      0002DB 74 10            [12] 2010 	mov	a,#(___str_5 >> 8)
      0002DD C0 E0            [24] 2011 	push	acc
      0002DF 12 07 F1         [24] 2012 	lcall	_printf_fast_f
      0002E2 15 81            [12] 2013 	dec	sp
      0002E4 15 81            [12] 2014 	dec	sp
                           00024D  2015 	C$p3main.c$117$3$45 ==.
                                   2016 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:117: printf_fast_f("r: Mede rotacao do motor.\n");
      0002E6 74 EF            [12] 2017 	mov	a,#___str_6
      0002E8 C0 E0            [24] 2018 	push	acc
      0002EA 74 10            [12] 2019 	mov	a,#(___str_6 >> 8)
      0002EC C0 E0            [24] 2020 	push	acc
      0002EE 12 07 F1         [24] 2021 	lcall	_printf_fast_f
      0002F1 15 81            [12] 2022 	dec	sp
      0002F3 15 81            [12] 2023 	dec	sp
                           00025C  2024 	C$p3main.c$118$3$45 ==.
                                   2025 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:118: printf_fast_f("1: Mede temperatura do motor.\n");
      0002F5 74 0A            [12] 2026 	mov	a,#___str_7
      0002F7 C0 E0            [24] 2027 	push	acc
      0002F9 74 11            [12] 2028 	mov	a,#(___str_7 >> 8)
      0002FB C0 E0            [24] 2029 	push	acc
      0002FD 12 07 F1         [24] 2030 	lcall	_printf_fast_f
      000300 15 81            [12] 2031 	dec	sp
      000302 15 81            [12] 2032 	dec	sp
                           00026B  2033 	C$p3main.c$119$3$45 ==.
                                   2034 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:119: printf_fast_f("2: Mede tensao aplicada a placa peltier.\n");
      000304 74 29            [12] 2035 	mov	a,#___str_8
      000306 C0 E0            [24] 2036 	push	acc
      000308 74 11            [12] 2037 	mov	a,#(___str_8 >> 8)
      00030A C0 E0            [24] 2038 	push	acc
      00030C 12 07 F1         [24] 2039 	lcall	_printf_fast_f
      00030F 15 81            [12] 2040 	dec	sp
      000311 15 81            [12] 2041 	dec	sp
                           00027A  2042 	C$p3main.c$120$3$45 ==.
                                   2043 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:120: printf_fast_f("3: Testa RAM SPI.\n");
      000313 74 53            [12] 2044 	mov	a,#___str_9
      000315 C0 E0            [24] 2045 	push	acc
      000317 74 11            [12] 2046 	mov	a,#(___str_9 >> 8)
      000319 C0 E0            [24] 2047 	push	acc
      00031B 12 07 F1         [24] 2048 	lcall	_printf_fast_f
      00031E 15 81            [12] 2049 	dec	sp
      000320 15 81            [12] 2050 	dec	sp
                           000289  2051 	C$p3main.c$121$3$45 ==.
                                   2052 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:121: printf_fast_f("\n");
      000322 74 66            [12] 2053 	mov	a,#___str_10
      000324 C0 E0            [24] 2054 	push	acc
      000326 74 11            [12] 2055 	mov	a,#(___str_10 >> 8)
      000328 C0 E0            [24] 2056 	push	acc
      00032A 12 07 F1         [24] 2057 	lcall	_printf_fast_f
      00032D 15 81            [12] 2058 	dec	sp
      00032F 15 81            [12] 2059 	dec	sp
                           000298  2060 	C$p3main.c$123$3$45 ==.
                                   2061 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:123: break;
      000331 02 04 6E         [24] 2062 	ljmp	00117$
                           00029B  2063 	C$p3main.c$126$3$45 ==.
                                   2064 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:126: case 'd':
      000334                       2065 00102$:
                           00029B  2066 	C$p3main.c$127$3$45 ==.
                                   2067 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:127: if (PCA0CPH0 < 255)
      000334 74 01            [12] 2068 	mov	a,#0x100 - 0xff
      000336 25 FC            [12] 2069 	add	a,_PCA0CPH0
      000338 50 03            [24] 2070 	jnc	00167$
      00033A 02 04 6E         [24] 2071 	ljmp	00117$
      00033D                       2072 00167$:
                           0002A4  2073 	C$p3main.c$128$3$45 ==.
                                   2074 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:128: PCA0CPH0++;
      00033D 05 FC            [12] 2075 	inc	_PCA0CPH0
                           0002A6  2076 	C$p3main.c$130$3$45 ==.
                                   2077 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:130: break;
      00033F 02 04 6E         [24] 2078 	ljmp	00117$
                           0002A9  2079 	C$p3main.c$133$3$45 ==.
                                   2080 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:133: case 'a':
      000342                       2081 00105$:
                           0002A9  2082 	C$p3main.c$134$3$45 ==.
                                   2083 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:134: if (PCA0CPH0 > 0)
      000342 E5 FC            [12] 2084 	mov	a,_PCA0CPH0
      000344 70 03            [24] 2085 	jnz	00168$
      000346 02 04 6E         [24] 2086 	ljmp	00117$
      000349                       2087 00168$:
                           0002B0  2088 	C$p3main.c$135$3$45 ==.
                                   2089 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:135: PCA0CPH0--;
      000349 15 FC            [12] 2090 	dec	_PCA0CPH0
                           0002B2  2091 	C$p3main.c$137$3$45 ==.
                                   2092 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:137: break;
      00034B 02 04 6E         [24] 2093 	ljmp	00117$
                           0002B5  2094 	C$p3main.c$140$3$45 ==.
                                   2095 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:140: case 'p':
      00034E                       2096 00108$:
                           0002B5  2097 	C$p3main.c$141$3$45 ==.
                                   2098 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:141: P0_7 = !P0_7;
      00034E B2 87            [12] 2099 	cpl	_P0_7
                           0002B7  2100 	C$p3main.c$143$3$45 ==.
                                   2101 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:143: printf_fast_f(" ");
      000350 74 68            [12] 2102 	mov	a,#___str_11
      000352 C0 E0            [24] 2103 	push	acc
      000354 74 11            [12] 2104 	mov	a,#(___str_11 >> 8)
      000356 C0 E0            [24] 2105 	push	acc
      000358 12 07 F1         [24] 2106 	lcall	_printf_fast_f
      00035B 15 81            [12] 2107 	dec	sp
      00035D 15 81            [12] 2108 	dec	sp
                           0002C6  2109 	C$p3main.c$145$3$45 ==.
                                   2110 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:145: if (P0_7)
      00035F 30 87 12         [24] 2111 	jnb	_P0_7,00110$
                           0002C9  2112 	C$p3main.c$146$3$45 ==.
                                   2113 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:146: printf_fast_f("Fonte 12V ligada.\n");
      000362 74 6A            [12] 2114 	mov	a,#___str_12
      000364 C0 E0            [24] 2115 	push	acc
      000366 74 11            [12] 2116 	mov	a,#(___str_12 >> 8)
      000368 C0 E0            [24] 2117 	push	acc
      00036A 12 07 F1         [24] 2118 	lcall	_printf_fast_f
      00036D 15 81            [12] 2119 	dec	sp
      00036F 15 81            [12] 2120 	dec	sp
      000371 02 04 6E         [24] 2121 	ljmp	00117$
      000374                       2122 00110$:
                           0002DB  2123 	C$p3main.c$148$3$45 ==.
                                   2124 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:148: printf_fast_f("Fonte 12V desligada.\n");
      000374 74 7D            [12] 2125 	mov	a,#___str_13
      000376 C0 E0            [24] 2126 	push	acc
      000378 74 11            [12] 2127 	mov	a,#(___str_13 >> 8)
      00037A C0 E0            [24] 2128 	push	acc
      00037C 12 07 F1         [24] 2129 	lcall	_printf_fast_f
      00037F 15 81            [12] 2130 	dec	sp
      000381 15 81            [12] 2131 	dec	sp
                           0002EA  2132 	C$p3main.c$150$3$45 ==.
                                   2133 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:150: break;
      000383 02 04 6E         [24] 2134 	ljmp	00117$
                           0002ED  2135 	C$p3main.c$153$3$45 ==.
                                   2136 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:153: case 'r':
      000386                       2137 00112$:
                           0002ED  2138 	C$p3main.c$154$3$45 ==.
                                   2139 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:154: printf_fast_f("Rotacao do motor: %3.1f\n", 30/(le_pulso()*10));
      000386 12 07 62         [24] 2140 	lcall	_le_pulso
      000389 AC 82            [24] 2141 	mov	r4,dpl
      00038B AD 83            [24] 2142 	mov	r5,dph
      00038D AE F0            [24] 2143 	mov	r6,b
      00038F FF               [12] 2144 	mov	r7,a
      000390 C0 04            [24] 2145 	push	ar4
      000392 C0 05            [24] 2146 	push	ar5
      000394 C0 06            [24] 2147 	push	ar6
      000396 C0 07            [24] 2148 	push	ar7
      000398 90 00 00         [24] 2149 	mov	dptr,#0x0000
      00039B 75 F0 20         [24] 2150 	mov	b,#0x20
      00039E 74 41            [12] 2151 	mov	a,#0x41
      0003A0 12 0C 72         [24] 2152 	lcall	___fsmul
      0003A3 AC 82            [24] 2153 	mov	r4,dpl
      0003A5 AD 83            [24] 2154 	mov	r5,dph
      0003A7 AE F0            [24] 2155 	mov	r6,b
      0003A9 FF               [12] 2156 	mov	r7,a
      0003AA E5 81            [12] 2157 	mov	a,sp
      0003AC 24 FC            [12] 2158 	add	a,#0xfc
      0003AE F5 81            [12] 2159 	mov	sp,a
      0003B0 C0 04            [24] 2160 	push	ar4
      0003B2 C0 05            [24] 2161 	push	ar5
      0003B4 C0 06            [24] 2162 	push	ar6
      0003B6 C0 07            [24] 2163 	push	ar7
      0003B8 90 00 00         [24] 2164 	mov	dptr,#0x0000
      0003BB 75 F0 F0         [24] 2165 	mov	b,#0xf0
      0003BE 74 41            [12] 2166 	mov	a,#0x41
      0003C0 12 0F 4D         [24] 2167 	lcall	___fsdiv
      0003C3 AC 82            [24] 2168 	mov	r4,dpl
      0003C5 AD 83            [24] 2169 	mov	r5,dph
      0003C7 AE F0            [24] 2170 	mov	r6,b
      0003C9 FF               [12] 2171 	mov	r7,a
      0003CA E5 81            [12] 2172 	mov	a,sp
      0003CC 24 FC            [12] 2173 	add	a,#0xfc
      0003CE F5 81            [12] 2174 	mov	sp,a
      0003D0 C0 04            [24] 2175 	push	ar4
      0003D2 C0 05            [24] 2176 	push	ar5
      0003D4 C0 06            [24] 2177 	push	ar6
      0003D6 C0 07            [24] 2178 	push	ar7
      0003D8 74 93            [12] 2179 	mov	a,#___str_14
      0003DA C0 E0            [24] 2180 	push	acc
      0003DC 74 11            [12] 2181 	mov	a,#(___str_14 >> 8)
      0003DE C0 E0            [24] 2182 	push	acc
      0003E0 12 07 F1         [24] 2183 	lcall	_printf_fast_f
      0003E3 E5 81            [12] 2184 	mov	a,sp
      0003E5 24 FA            [12] 2185 	add	a,#0xfa
      0003E7 F5 81            [12] 2186 	mov	sp,a
                           000350  2187 	C$p3main.c$155$3$45 ==.
                                   2188 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:155: break;
      0003E9 02 04 6E         [24] 2189 	ljmp	00117$
                           000353  2190 	C$p3main.c$158$3$45 ==.
                                   2191 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:158: case '1':
      0003EC                       2192 00113$:
                           000353  2193 	C$p3main.c$159$3$45 ==.
                                   2194 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:159: P3_1 = 0;
      0003EC C2 B1            [12] 2195 	clr	_P3_1
                           000355  2196 	C$p3main.c$160$3$45 ==.
                                   2197 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:160: delay_ms(5);
      0003EE 90 00 05         [24] 2198 	mov	dptr,#0x0005
      0003F1 12 02 23         [24] 2199 	lcall	_delay_ms
                           00035B  2200 	C$p3main.c$161$3$45 ==.
                                   2201 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:161: P3_1 = 1;
      0003F4 D2 B1            [12] 2202 	setb	_P3_1
                           00035D  2203 	C$p3main.c$162$3$45 ==.
                                   2204 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:162: delay_ms(5);
      0003F6 90 00 05         [24] 2205 	mov	dptr,#0x0005
      0003F9 12 02 23         [24] 2206 	lcall	_delay_ms
                           000363  2207 	C$p3main.c$163$3$45 ==.
                                   2208 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:163: P3_1 = 0;
      0003FC C2 B1            [12] 2209 	clr	_P3_1
                           000365  2210 	C$p3main.c$165$3$45 ==.
                                   2211 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:165: delay_ms(150); 
      0003FE 90 00 96         [24] 2212 	mov	dptr,#0x0096
      000401 12 02 23         [24] 2213 	lcall	_delay_ms
                           00036B  2214 	C$p3main.c$167$3$45 ==.
                                   2215 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:167: P3_1 = 1;
      000404 D2 B1            [12] 2216 	setb	_P3_1
                           00036D  2217 	C$p3main.c$168$3$45 ==.
                                   2218 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:168: delay_ms(5);
      000406 90 00 05         [24] 2219 	mov	dptr,#0x0005
      000409 12 02 23         [24] 2220 	lcall	_delay_ms
                           000373  2221 	C$p3main.c$169$3$45 ==.
                                   2222 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:169: P3_1 = 0;
      00040C C2 B1            [12] 2223 	clr	_P3_1
                           000375  2224 	C$p3main.c$170$3$45 ==.
                                   2225 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:170: delay_ms(5);
      00040E 90 00 05         [24] 2226 	mov	dptr,#0x0005
      000411 12 02 23         [24] 2227 	lcall	_delay_ms
                           00037B  2228 	C$p3main.c$171$3$45 ==.
                                   2229 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:171: P3_1 = 1;
      000414 D2 B1            [12] 2230 	setb	_P3_1
                           00037D  2231 	C$p3main.c$172$3$45 ==.
                                   2232 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:172: break;
                           00037D  2233 	C$p3main.c$175$3$45 ==.
                                   2234 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:175: case '2':
      000416 80 56            [24] 2235 	sjmp	00117$
      000418                       2236 00114$:
                           00037F  2237 	C$p3main.c$176$3$45 ==.
                                   2238 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:176: P3_2 = 0;
      000418 C2 B2            [12] 2239 	clr	_P3_2
                           000381  2240 	C$p3main.c$177$3$45 ==.
                                   2241 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:177: delay_ms(5);
      00041A 90 00 05         [24] 2242 	mov	dptr,#0x0005
      00041D 12 02 23         [24] 2243 	lcall	_delay_ms
                           000387  2244 	C$p3main.c$178$3$45 ==.
                                   2245 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:178: P3_2 = 1;
      000420 D2 B2            [12] 2246 	setb	_P3_2
                           000389  2247 	C$p3main.c$179$3$45 ==.
                                   2248 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:179: delay_ms(5);
      000422 90 00 05         [24] 2249 	mov	dptr,#0x0005
      000425 12 02 23         [24] 2250 	lcall	_delay_ms
                           00038F  2251 	C$p3main.c$180$3$45 ==.
                                   2252 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:180: P3_2 = 0;
      000428 C2 B2            [12] 2253 	clr	_P3_2
                           000391  2254 	C$p3main.c$182$3$45 ==.
                                   2255 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:182: delay_ms(150); 
      00042A 90 00 96         [24] 2256 	mov	dptr,#0x0096
      00042D 12 02 23         [24] 2257 	lcall	_delay_ms
                           000397  2258 	C$p3main.c$184$3$45 ==.
                                   2259 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:184: P3_2 = 1;
      000430 D2 B2            [12] 2260 	setb	_P3_2
                           000399  2261 	C$p3main.c$185$3$45 ==.
                                   2262 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:185: delay_ms(5);
      000432 90 00 05         [24] 2263 	mov	dptr,#0x0005
      000435 12 02 23         [24] 2264 	lcall	_delay_ms
                           00039F  2265 	C$p3main.c$186$3$45 ==.
                                   2266 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:186: P3_2 = 0;
      000438 C2 B2            [12] 2267 	clr	_P3_2
                           0003A1  2268 	C$p3main.c$187$3$45 ==.
                                   2269 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:187: delay_ms(5);
      00043A 90 00 05         [24] 2270 	mov	dptr,#0x0005
      00043D 12 02 23         [24] 2271 	lcall	_delay_ms
                           0003A7  2272 	C$p3main.c$188$3$45 ==.
                                   2273 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:188: P3_2 = 1;
      000440 D2 B2            [12] 2274 	setb	_P3_2
                           0003A9  2275 	C$p3main.c$189$3$45 ==.
                                   2276 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:189: break;
                           0003A9  2277 	C$p3main.c$192$3$45 ==.
                                   2278 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:192: case '3':
      000442 80 2A            [24] 2279 	sjmp	00117$
      000444                       2280 00115$:
                           0003AB  2281 	C$p3main.c$193$3$45 ==.
                                   2282 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:193: P3_3 = 0;
      000444 C2 B3            [12] 2283 	clr	_P3_3
                           0003AD  2284 	C$p3main.c$194$3$45 ==.
                                   2285 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:194: delay_ms(5);
      000446 90 00 05         [24] 2286 	mov	dptr,#0x0005
      000449 12 02 23         [24] 2287 	lcall	_delay_ms
                           0003B3  2288 	C$p3main.c$195$3$45 ==.
                                   2289 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:195: P3_3 = 1;
      00044C D2 B3            [12] 2290 	setb	_P3_3
                           0003B5  2291 	C$p3main.c$196$3$45 ==.
                                   2292 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:196: delay_ms(5);
      00044E 90 00 05         [24] 2293 	mov	dptr,#0x0005
      000451 12 02 23         [24] 2294 	lcall	_delay_ms
                           0003BB  2295 	C$p3main.c$197$3$45 ==.
                                   2296 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:197: P3_3 = 0;
      000454 C2 B3            [12] 2297 	clr	_P3_3
                           0003BD  2298 	C$p3main.c$199$3$45 ==.
                                   2299 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:199: delay_ms(150); 
      000456 90 00 96         [24] 2300 	mov	dptr,#0x0096
      000459 12 02 23         [24] 2301 	lcall	_delay_ms
                           0003C3  2302 	C$p3main.c$201$3$45 ==.
                                   2303 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:201: P3_3 = 1;
      00045C D2 B3            [12] 2304 	setb	_P3_3
                           0003C5  2305 	C$p3main.c$202$3$45 ==.
                                   2306 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:202: delay_ms(5);
      00045E 90 00 05         [24] 2307 	mov	dptr,#0x0005
      000461 12 02 23         [24] 2308 	lcall	_delay_ms
                           0003CB  2309 	C$p3main.c$203$3$45 ==.
                                   2310 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:203: P3_3 = 0;
      000464 C2 B3            [12] 2311 	clr	_P3_3
                           0003CD  2312 	C$p3main.c$204$3$45 ==.
                                   2313 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:204: delay_ms(5);
      000466 90 00 05         [24] 2314 	mov	dptr,#0x0005
      000469 12 02 23         [24] 2315 	lcall	_delay_ms
                           0003D3  2316 	C$p3main.c$205$3$45 ==.
                                   2317 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:205: P3_3 = 1;
      00046C D2 B3            [12] 2318 	setb	_P3_3
                           0003D5  2319 	C$p3main.c$210$2$44 ==.
                                   2320 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:210: }
      00046E                       2321 00117$:
                           0003D5  2322 	C$p3main.c$212$2$44 ==.
                                   2323 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:212: RI0 = 0;
      00046E C2 98            [12] 2324 	clr	_RI0
      000470                       2325 00120$:
      000470 D0 D0            [24] 2326 	pop	psw
      000472 D0 00            [24] 2327 	pop	(0+0)
      000474 D0 01            [24] 2328 	pop	(0+1)
      000476 D0 02            [24] 2329 	pop	(0+2)
      000478 D0 03            [24] 2330 	pop	(0+3)
      00047A D0 04            [24] 2331 	pop	(0+4)
      00047C D0 05            [24] 2332 	pop	(0+5)
      00047E D0 06            [24] 2333 	pop	(0+6)
      000480 D0 07            [24] 2334 	pop	(0+7)
      000482 D0 83            [24] 2335 	pop	dph
      000484 D0 82            [24] 2336 	pop	dpl
      000486 D0 F0            [24] 2337 	pop	b
      000488 D0 E0            [24] 2338 	pop	acc
      00048A D0 21            [24] 2339 	pop	bits
                           0003F3  2340 	C$p3main.c$214$1$43 ==.
                           0003F3  2341 	XG$int_serial$0$0 ==.
      00048C 32               [24] 2342 	reti
                                   2343 ;------------------------------------------------------------
                                   2344 ;Allocation info for local variables in function 'le_tec'
                                   2345 ;------------------------------------------------------------
                                   2346 ;vp                        Allocated to registers r7 
                                   2347 ;i                         Allocated to registers r6 
                                   2348 ;m                         Allocated to registers 
                                   2349 ;------------------------------------------------------------
                           0003F4  2350 	G$le_tec$0$0 ==.
                           0003F4  2351 	C$p3main.c$217$1$43 ==.
                                   2352 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:217: unsigned char le_tec(void) {
                                   2353 ;	-----------------------------------------
                                   2354 ;	 function le_tec
                                   2355 ;	-----------------------------------------
      00048D                       2356 _le_tec:
                           0003F4  2357 	C$p3main.c$219$1$47 ==.
                                   2358 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:219: if(P3 != 0xff)
      00048D 74 FF            [12] 2359 	mov	a,#0xff
      00048F B5 B0 02         [24] 2360 	cjne	a,_P3,00123$
      000492 80 06            [24] 2361 	sjmp	00102$
      000494                       2362 00123$:
                           0003FB  2363 	C$p3main.c$221$2$48 ==.
                                   2364 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:221: vp = ~P3;
      000494 E5 B0            [12] 2365 	mov	a,_P3
      000496 F4               [12] 2366 	cpl	a
      000497 FF               [12] 2367 	mov	r7,a
                           0003FF  2368 	C$p3main.c$222$1$47 ==.
                                   2369 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:222: m = 0;
      000498 80 05            [24] 2370 	sjmp	00113$
      00049A                       2371 00102$:
                           000401  2372 	C$p3main.c$226$1$47 ==.
                                   2373 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:226: return 21;
      00049A 75 82 15         [24] 2374 	mov	dpl,#0x15
                           000404  2375 	C$p3main.c$228$1$47 ==.
                                   2376 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:228: while((vp & 0x01)==0 && i<8)
      00049D 80 14            [24] 2377 	sjmp	00108$
      00049F                       2378 00113$:
      00049F 7E 00            [12] 2379 	mov	r6,#0x00
      0004A1                       2380 00105$:
      0004A1 EF               [12] 2381 	mov	a,r7
      0004A2 20 E0 0C         [24] 2382 	jb	acc.0,00107$
      0004A5 BE 08 00         [24] 2383 	cjne	r6,#0x08,00125$
      0004A8                       2384 00125$:
      0004A8 50 07            [24] 2385 	jnc	00107$
                           000411  2386 	C$p3main.c$230$2$49 ==.
                                   2387 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:230: vp = vp >> 1;
      0004AA EF               [12] 2388 	mov	a,r7
      0004AB C3               [12] 2389 	clr	c
      0004AC 13               [12] 2390 	rrc	a
      0004AD FF               [12] 2391 	mov	r7,a
                           000415  2392 	C$p3main.c$231$2$49 ==.
                                   2393 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:231: i++;
      0004AE 0E               [12] 2394 	inc	r6
      0004AF 80 F0            [24] 2395 	sjmp	00105$
      0004B1                       2396 00107$:
                           000418  2397 	C$p3main.c$234$1$47 ==.
                                   2398 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:234: return(i+m*8);
      0004B1 8E 82            [24] 2399 	mov	dpl,r6
      0004B3                       2400 00108$:
                           00041A  2401 	C$p3main.c$235$1$47 ==.
                           00041A  2402 	XG$le_tec$0$0 ==.
      0004B3 22               [24] 2403 	ret
                                   2404 ;------------------------------------------------------------
                                   2405 ;Allocation info for local variables in function 'isr_timer2'
                                   2406 ;------------------------------------------------------------
                           00041B  2407 	G$isr_timer2$0$0 ==.
                           00041B  2408 	C$p3main.c$237$1$47 ==.
                                   2409 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:237: void isr_timer2() __interrupt 5
                                   2410 ;	-----------------------------------------
                                   2411 ;	 function isr_timer2
                                   2412 ;	-----------------------------------------
      0004B4                       2413 _isr_timer2:
      0004B4 C0 21            [24] 2414 	push	bits
      0004B6 C0 E0            [24] 2415 	push	acc
      0004B8 C0 F0            [24] 2416 	push	b
      0004BA C0 82            [24] 2417 	push	dpl
      0004BC C0 83            [24] 2418 	push	dph
      0004BE C0 07            [24] 2419 	push	(0+7)
      0004C0 C0 06            [24] 2420 	push	(0+6)
      0004C2 C0 05            [24] 2421 	push	(0+5)
      0004C4 C0 04            [24] 2422 	push	(0+4)
      0004C6 C0 03            [24] 2423 	push	(0+3)
      0004C8 C0 02            [24] 2424 	push	(0+2)
      0004CA C0 01            [24] 2425 	push	(0+1)
      0004CC C0 00            [24] 2426 	push	(0+0)
      0004CE C0 D0            [24] 2427 	push	psw
      0004D0 75 D0 00         [24] 2428 	mov	psw,#0x00
                           00043A  2429 	C$p3main.c$241$1$50 ==.
                                   2430 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:241: TF2 = 0; // zera overflow
      0004D3 C2 CF            [12] 2431 	clr	_TF2
                           00043C  2432 	C$p3main.c$243$1$50 ==.
                                   2433 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:243: if(P3 == 0xff)
      0004D5 74 FF            [12] 2434 	mov	a,#0xff
      0004D7 B5 B0 03         [24] 2435 	cjne	a,_P3,00102$
                           000441  2436 	C$p3main.c$244$1$50 ==.
                                   2437 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:244: estado = 0;
      0004DA 75 09 00         [24] 2438 	mov	_estado,#0x00
      0004DD                       2439 00102$:
                           000444  2440 	C$p3main.c$245$1$50 ==.
                                   2441 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:245: if(estado == 0)
      0004DD E5 09            [12] 2442 	mov	a,_estado
      0004DF 70 06            [24] 2443 	jnz	00104$
                           000448  2444 	C$p3main.c$247$2$51 ==.
                                   2445 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:247: tecla = le_tec();
      0004E1 12 04 8D         [24] 2446 	lcall	_le_tec
      0004E4 85 82 08         [24] 2447 	mov	_tecla,dpl
      0004E7                       2448 00104$:
                           00044E  2449 	C$p3main.c$249$1$50 ==.
                                   2450 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:249: if(tecla != 21 && estado == 0)
      0004E7 74 15            [12] 2451 	mov	a,#0x15
      0004E9 B5 08 02         [24] 2452 	cjne	a,_tecla,00125$
      0004EC 80 07            [24] 2453 	sjmp	00108$
      0004EE                       2454 00125$:
      0004EE E5 09            [12] 2455 	mov	a,_estado
      0004F0 70 03            [24] 2456 	jnz	00108$
                           000459  2457 	C$p3main.c$251$2$52 ==.
                                   2458 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:251: estado = 1;
      0004F2 75 09 01         [24] 2459 	mov	_estado,#0x01
      0004F5                       2460 00108$:
      0004F5 D0 D0            [24] 2461 	pop	psw
      0004F7 D0 00            [24] 2462 	pop	(0+0)
      0004F9 D0 01            [24] 2463 	pop	(0+1)
      0004FB D0 02            [24] 2464 	pop	(0+2)
      0004FD D0 03            [24] 2465 	pop	(0+3)
      0004FF D0 04            [24] 2466 	pop	(0+4)
      000501 D0 05            [24] 2467 	pop	(0+5)
      000503 D0 06            [24] 2468 	pop	(0+6)
      000505 D0 07            [24] 2469 	pop	(0+7)
      000507 D0 83            [24] 2470 	pop	dph
      000509 D0 82            [24] 2471 	pop	dpl
      00050B D0 F0            [24] 2472 	pop	b
      00050D D0 E0            [24] 2473 	pop	acc
      00050F D0 21            [24] 2474 	pop	bits
                           000478  2475 	C$p3main.c$254$1$50 ==.
                           000478  2476 	XG$isr_timer2$0$0 ==.
      000511 32               [24] 2477 	reti
                                   2478 ;------------------------------------------------------------
                                   2479 ;Allocation info for local variables in function 'le_RAM_SPI'
                                   2480 ;------------------------------------------------------------
                                   2481 ;end                       Allocated to registers r6 r7 
                                   2482 ;end_L                     Allocated to registers r5 
                                   2483 ;end_H                     Allocated to registers r7 
                                   2484 ;------------------------------------------------------------
                           000479  2485 	G$le_RAM_SPI$0$0 ==.
                           000479  2486 	C$p3main.c$257$1$50 ==.
                                   2487 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:257: unsigned char le_RAM_SPI(unsigned int end) {
                                   2488 ;	-----------------------------------------
                                   2489 ;	 function le_RAM_SPI
                                   2490 ;	-----------------------------------------
      000512                       2491 _le_RAM_SPI:
      000512 AE 82            [24] 2492 	mov	r6,dpl
      000514 AF 83            [24] 2493 	mov	r7,dph
                           00047D  2494 	C$p3main.c$259$1$54 ==.
                                   2495 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:259: end_L = end;
      000516 8E 05            [24] 2496 	mov	ar5,r6
                           00047F  2497 	C$p3main.c$260$1$54 ==.
                                   2498 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:260: end_H = end >> 8;
                           00047F  2499 	C$p3main.c$261$1$54 ==.
                                   2500 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:261: CS = 0;
      000518 C2 A3            [12] 2501 	clr	_P2_3
                           000481  2502 	C$p3main.c$263$1$54 ==.
                                   2503 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:263: SPI0DAT = 0x03; //codigo da leitura
      00051A 75 9B 03         [24] 2504 	mov	_SPI0DAT,#0x03
                           000484  2505 	C$p3main.c$264$1$54 ==.
                                   2506 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:264: while(!TXBMT);
      00051D                       2507 00101$:
      00051D 30 F9 FD         [24] 2508 	jnb	_TXBMT,00101$
                           000487  2509 	C$p3main.c$265$1$54 ==.
                                   2510 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:265: SPI0DAT = end_H;
      000520 8F 9B            [24] 2511 	mov	_SPI0DAT,r7
                           000489  2512 	C$p3main.c$266$1$54 ==.
                                   2513 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:266: while(!TXBMT);
      000522                       2514 00104$:
      000522 30 F9 FD         [24] 2515 	jnb	_TXBMT,00104$
                           00048C  2516 	C$p3main.c$267$1$54 ==.
                                   2517 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:267: SPI0DAT = end_L;
      000525 8D 9B            [24] 2518 	mov	_SPI0DAT,r5
                           00048E  2519 	C$p3main.c$268$1$54 ==.
                                   2520 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:268: while(!TXBMT);
      000527                       2521 00107$:
      000527 30 F9 FD         [24] 2522 	jnb	_TXBMT,00107$
                           000491  2523 	C$p3main.c$269$1$54 ==.
                                   2524 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:269: SPI0DAT = 0x00;
      00052A 75 9B 00         [24] 2525 	mov	_SPI0DAT,#0x00
                           000494  2526 	C$p3main.c$270$1$54 ==.
                                   2527 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:270: while(!TXBMT);
      00052D                       2528 00110$:
      00052D 30 F9 FD         [24] 2529 	jnb	_TXBMT,00110$
                           000497  2530 	C$p3main.c$271$1$54 ==.
                                   2531 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:271: SPIF = 0;
      000530 C2 FF            [12] 2532 	clr	_SPIF
                           000499  2533 	C$p3main.c$272$1$54 ==.
                                   2534 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:272: while(!SPIF); // espera o t�rmino do deslocamento do �ltimo valor
      000532                       2535 00113$:
                           000499  2536 	C$p3main.c$273$1$54 ==.
                                   2537 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:273: SPIF = 0;
      000532 10 FF 02         [24] 2538 	jbc	_SPIF,00152$
      000535 80 FB            [24] 2539 	sjmp	00113$
      000537                       2540 00152$:
                           00049E  2541 	C$p3main.c$274$1$54 ==.
                                   2542 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:274: CS = 1;
      000537 D2 A3            [12] 2543 	setb	_P2_3
                           0004A0  2544 	C$p3main.c$276$1$54 ==.
                                   2545 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:276: return (SPI0DAT);   
      000539 85 9B 82         [24] 2546 	mov	dpl,_SPI0DAT
                           0004A3  2547 	C$p3main.c$277$1$54 ==.
                           0004A3  2548 	XG$le_RAM_SPI$0$0 ==.
      00053C 22               [24] 2549 	ret
                                   2550 ;------------------------------------------------------------
                                   2551 ;Allocation info for local variables in function 'esc_RAM_SPI'
                                   2552 ;------------------------------------------------------------
                                   2553 ;dado                      Allocated with name '_esc_RAM_SPI_PARM_2'
                                   2554 ;end                       Allocated to registers r6 r7 
                                   2555 ;end_L                     Allocated to registers r5 
                                   2556 ;end_H                     Allocated to registers r7 
                                   2557 ;------------------------------------------------------------
                           0004A4  2558 	G$esc_RAM_SPI$0$0 ==.
                           0004A4  2559 	C$p3main.c$279$1$54 ==.
                                   2560 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:279: void esc_RAM_SPI(unsigned int end, unsigned char dado) {
                                   2561 ;	-----------------------------------------
                                   2562 ;	 function esc_RAM_SPI
                                   2563 ;	-----------------------------------------
      00053D                       2564 _esc_RAM_SPI:
      00053D AE 82            [24] 2565 	mov	r6,dpl
      00053F AF 83            [24] 2566 	mov	r7,dph
                           0004A8  2567 	C$p3main.c$281$1$56 ==.
                                   2568 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:281: end_L = end;
      000541 8E 05            [24] 2569 	mov	ar5,r6
                           0004AA  2570 	C$p3main.c$282$1$56 ==.
                                   2571 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:282: end_H = end >> 8;
                           0004AA  2572 	C$p3main.c$283$1$56 ==.
                                   2573 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:283: CS = 0;    
      000543 C2 A3            [12] 2574 	clr	_P2_3
                           0004AC  2575 	C$p3main.c$285$1$56 ==.
                                   2576 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:285: SPI0DAT = 0x02; //codigo da escrita
      000545 75 9B 02         [24] 2577 	mov	_SPI0DAT,#0x02
                           0004AF  2578 	C$p3main.c$286$1$56 ==.
                                   2579 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:286: while(!TXBMT);
      000548                       2580 00101$:
      000548 30 F9 FD         [24] 2581 	jnb	_TXBMT,00101$
                           0004B2  2582 	C$p3main.c$287$1$56 ==.
                                   2583 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:287: SPI0DAT = end_H;
      00054B 8F 9B            [24] 2584 	mov	_SPI0DAT,r7
                           0004B4  2585 	C$p3main.c$288$1$56 ==.
                                   2586 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:288: while(!TXBMT);
      00054D                       2587 00104$:
      00054D 30 F9 FD         [24] 2588 	jnb	_TXBMT,00104$
                           0004B7  2589 	C$p3main.c$289$1$56 ==.
                                   2590 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:289: SPI0DAT = end_L;
      000550 8D 9B            [24] 2591 	mov	_SPI0DAT,r5
                           0004B9  2592 	C$p3main.c$290$1$56 ==.
                                   2593 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:290: while(!TXBMT);
      000552                       2594 00107$:
      000552 30 F9 FD         [24] 2595 	jnb	_TXBMT,00107$
                           0004BC  2596 	C$p3main.c$291$1$56 ==.
                                   2597 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:291: SPI0DAT = dado;
      000555 85 15 9B         [24] 2598 	mov	_SPI0DAT,_esc_RAM_SPI_PARM_2
                           0004BF  2599 	C$p3main.c$292$1$56 ==.
                                   2600 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:292: while(!TXBMT);
      000558                       2601 00110$:
      000558 30 F9 FD         [24] 2602 	jnb	_TXBMT,00110$
                           0004C2  2603 	C$p3main.c$293$1$56 ==.
                                   2604 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:293: SPIF = 0;
      00055B C2 FF            [12] 2605 	clr	_SPIF
                           0004C4  2606 	C$p3main.c$294$1$56 ==.
                                   2607 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:294: while(!SPIF); // espera o t�rmino do deslocamento do �ltimo valor
      00055D                       2608 00113$:
                           0004C4  2609 	C$p3main.c$295$1$56 ==.
                                   2610 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:295: SPIF = 0;
      00055D 10 FF 02         [24] 2611 	jbc	_SPIF,00152$
      000560 80 FB            [24] 2612 	sjmp	00113$
      000562                       2613 00152$:
                           0004C9  2614 	C$p3main.c$296$1$56 ==.
                                   2615 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:296: CS = 1;
      000562 D2 A3            [12] 2616 	setb	_P2_3
                           0004CB  2617 	C$p3main.c$297$1$56 ==.
                           0004CB  2618 	XG$esc_RAM_SPI$0$0 ==.
      000564 22               [24] 2619 	ret
                                   2620 ;------------------------------------------------------------
                                   2621 ;Allocation info for local variables in function 'test_RAM_SPI'
                                   2622 ;------------------------------------------------------------
                                   2623 ;end                       Allocated to registers r4 r5 
                                   2624 ;error                     Allocated to registers r6 r7 
                                   2625 ;------------------------------------------------------------
                           0004CC  2626 	G$test_RAM_SPI$0$0 ==.
                           0004CC  2627 	C$p3main.c$299$1$56 ==.
                                   2628 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:299: void test_RAM_SPI() {
                                   2629 ;	-----------------------------------------
                                   2630 ;	 function test_RAM_SPI
                                   2631 ;	-----------------------------------------
      000565                       2632 _test_RAM_SPI:
                           0004CC  2633 	C$p3main.c$300$1$56 ==.
                                   2634 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:300: unsigned int end, error = 0;
      000565 7E 00            [12] 2635 	mov	r6,#0x00
      000567 7F 00            [12] 2636 	mov	r7,#0x00
                           0004D0  2637 	C$p3main.c$302$2$58 ==.
                                   2638 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:302: for (end = 0; end < 8192; end++) {
      000569 7C 00            [12] 2639 	mov	r4,#0x00
      00056B 7D 00            [12] 2640 	mov	r5,#0x00
      00056D                       2641 00109$:
                           0004D4  2642 	C$p3main.c$303$1$57 ==.
                                   2643 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:303: if (end % 100 == 0)
      00056D 75 15 64         [24] 2644 	mov	__moduint_PARM_2,#0x64
      000570 75 16 00         [24] 2645 	mov	(__moduint_PARM_2 + 1),#0x00
      000573 8C 82            [24] 2646 	mov	dpl,r4
      000575 8D 83            [24] 2647 	mov	dph,r5
      000577 C0 07            [24] 2648 	push	ar7
      000579 C0 06            [24] 2649 	push	ar6
      00057B C0 05            [24] 2650 	push	ar5
      00057D C0 04            [24] 2651 	push	ar4
      00057F 12 0D E9         [24] 2652 	lcall	__moduint
      000582 E5 82            [12] 2653 	mov	a,dpl
      000584 85 83 F0         [24] 2654 	mov	b,dph
      000587 D0 04            [24] 2655 	pop	ar4
      000589 D0 05            [24] 2656 	pop	ar5
      00058B D0 06            [24] 2657 	pop	ar6
      00058D D0 07            [24] 2658 	pop	ar7
      00058F 45 F0            [12] 2659 	orl	a,b
      000591 70 25            [24] 2660 	jnz	00102$
                           0004FA  2661 	C$p3main.c$304$2$58 ==.
                                   2662 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:304: printf_fast_f("%05u ", end);
      000593 C0 07            [24] 2663 	push	ar7
      000595 C0 06            [24] 2664 	push	ar6
      000597 C0 05            [24] 2665 	push	ar5
      000599 C0 04            [24] 2666 	push	ar4
      00059B C0 04            [24] 2667 	push	ar4
      00059D C0 05            [24] 2668 	push	ar5
      00059F 74 AC            [12] 2669 	mov	a,#___str_15
      0005A1 C0 E0            [24] 2670 	push	acc
      0005A3 74 11            [12] 2671 	mov	a,#(___str_15 >> 8)
      0005A5 C0 E0            [24] 2672 	push	acc
      0005A7 12 07 F1         [24] 2673 	lcall	_printf_fast_f
      0005AA E5 81            [12] 2674 	mov	a,sp
      0005AC 24 FC            [12] 2675 	add	a,#0xfc
      0005AE F5 81            [12] 2676 	mov	sp,a
      0005B0 D0 04            [24] 2677 	pop	ar4
      0005B2 D0 05            [24] 2678 	pop	ar5
      0005B4 D0 06            [24] 2679 	pop	ar6
      0005B6 D0 07            [24] 2680 	pop	ar7
      0005B8                       2681 00102$:
                           00051F  2682 	C$p3main.c$305$2$58 ==.
                                   2683 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:305: esc_RAM_SPI(end, 123);
      0005B8 75 15 7B         [24] 2684 	mov	_esc_RAM_SPI_PARM_2,#0x7b
      0005BB 8C 82            [24] 2685 	mov	dpl,r4
      0005BD 8D 83            [24] 2686 	mov	dph,r5
      0005BF C0 07            [24] 2687 	push	ar7
      0005C1 C0 06            [24] 2688 	push	ar6
      0005C3 C0 05            [24] 2689 	push	ar5
      0005C5 C0 04            [24] 2690 	push	ar4
      0005C7 12 05 3D         [24] 2691 	lcall	_esc_RAM_SPI
      0005CA D0 04            [24] 2692 	pop	ar4
      0005CC D0 05            [24] 2693 	pop	ar5
                           000535  2694 	C$p3main.c$306$2$58 ==.
                                   2695 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:306: if (le_RAM_SPI(end) != 123) {
      0005CE 8C 82            [24] 2696 	mov	dpl,r4
      0005D0 8D 83            [24] 2697 	mov	dph,r5
      0005D2 C0 05            [24] 2698 	push	ar5
      0005D4 C0 04            [24] 2699 	push	ar4
      0005D6 12 05 12         [24] 2700 	lcall	_le_RAM_SPI
      0005D9 AB 82            [24] 2701 	mov	r3,dpl
      0005DB D0 04            [24] 2702 	pop	ar4
      0005DD D0 05            [24] 2703 	pop	ar5
      0005DF D0 06            [24] 2704 	pop	ar6
      0005E1 D0 07            [24] 2705 	pop	ar7
      0005E3 BB 7B 02         [24] 2706 	cjne	r3,#0x7b,00126$
      0005E6 80 06            [24] 2707 	sjmp	00110$
      0005E8                       2708 00126$:
                           00054F  2709 	C$p3main.c$307$3$59 ==.
                                   2710 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:307: error = 1;
      0005E8 7E 01            [12] 2711 	mov	r6,#0x01
      0005EA 7F 00            [12] 2712 	mov	r7,#0x00
                           000553  2713 	C$p3main.c$308$3$59 ==.
                                   2714 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:308: break;
      0005EC 80 0D            [24] 2715 	sjmp	00105$
      0005EE                       2716 00110$:
                           000555  2717 	C$p3main.c$302$1$57 ==.
                                   2718 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:302: for (end = 0; end < 8192; end++) {
      0005EE 0C               [12] 2719 	inc	r4
      0005EF BC 00 01         [24] 2720 	cjne	r4,#0x00,00127$
      0005F2 0D               [12] 2721 	inc	r5
      0005F3                       2722 00127$:
      0005F3 74 E0            [12] 2723 	mov	a,#0x100 - 0x20
      0005F5 2D               [12] 2724 	add	a,r5
      0005F6 40 03            [24] 2725 	jc	00128$
      0005F8 02 05 6D         [24] 2726 	ljmp	00109$
      0005FB                       2727 00128$:
      0005FB                       2728 00105$:
                           000562  2729 	C$p3main.c$312$1$57 ==.
                                   2730 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:312: printf_fast_f("\n");
      0005FB C0 07            [24] 2731 	push	ar7
      0005FD C0 06            [24] 2732 	push	ar6
      0005FF 74 66            [12] 2733 	mov	a,#___str_10
      000601 C0 E0            [24] 2734 	push	acc
      000603 74 11            [12] 2735 	mov	a,#(___str_10 >> 8)
      000605 C0 E0            [24] 2736 	push	acc
      000607 12 07 F1         [24] 2737 	lcall	_printf_fast_f
      00060A 15 81            [12] 2738 	dec	sp
      00060C 15 81            [12] 2739 	dec	sp
      00060E D0 06            [24] 2740 	pop	ar6
      000610 D0 07            [24] 2741 	pop	ar7
                           000579  2742 	C$p3main.c$314$1$57 ==.
                                   2743 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:314: if(error)
      000612 EE               [12] 2744 	mov	a,r6
      000613 4F               [12] 2745 	orl	a,r7
      000614 60 17            [24] 2746 	jz	00107$
                           00057D  2747 	C$p3main.c$315$1$57 ==.
                                   2748 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:315: printf_fast_f("Erro end. %05u\n", error);
      000616 C0 06            [24] 2749 	push	ar6
      000618 C0 07            [24] 2750 	push	ar7
      00061A 74 B2            [12] 2751 	mov	a,#___str_16
      00061C C0 E0            [24] 2752 	push	acc
      00061E 74 11            [12] 2753 	mov	a,#(___str_16 >> 8)
      000620 C0 E0            [24] 2754 	push	acc
      000622 12 07 F1         [24] 2755 	lcall	_printf_fast_f
      000625 E5 81            [12] 2756 	mov	a,sp
      000627 24 FC            [12] 2757 	add	a,#0xfc
      000629 F5 81            [12] 2758 	mov	sp,a
      00062B 80 0F            [24] 2759 	sjmp	00111$
      00062D                       2760 00107$:
                           000594  2761 	C$p3main.c$317$1$57 ==.
                                   2762 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:317: printf_fast_f("Fim do teste. RAM SPI ok!\n");		
      00062D 74 C2            [12] 2763 	mov	a,#___str_17
      00062F C0 E0            [24] 2764 	push	acc
      000631 74 11            [12] 2765 	mov	a,#(___str_17 >> 8)
      000633 C0 E0            [24] 2766 	push	acc
      000635 12 07 F1         [24] 2767 	lcall	_printf_fast_f
      000638 15 81            [12] 2768 	dec	sp
      00063A 15 81            [12] 2769 	dec	sp
      00063C                       2770 00111$:
                           0005A3  2771 	C$p3main.c$318$1$57 ==.
                           0005A3  2772 	XG$test_RAM_SPI$0$0 ==.
      00063C 22               [24] 2773 	ret
                                   2774 ;------------------------------------------------------------
                                   2775 ;Allocation info for local variables in function 'le_ADC0'
                                   2776 ;------------------------------------------------------------
                                   2777 ;ganho                     Allocated with name '_le_ADC0_PARM_2'
                                   2778 ;canal                     Allocated to registers r7 
                                   2779 ;------------------------------------------------------------
                           0005A4  2780 	G$le_ADC0$0$0 ==.
                           0005A4  2781 	C$p3main.c$321$1$57 ==.
                                   2782 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:321: unsigned int le_ADC0(unsigned char canal, unsigned char ganho) {
                                   2783 ;	-----------------------------------------
                                   2784 ;	 function le_ADC0
                                   2785 ;	-----------------------------------------
      00063D                       2786 _le_ADC0:
      00063D AF 82            [24] 2787 	mov	r7,dpl
                           0005A6  2788 	C$p3main.c$322$1$61 ==.
                                   2789 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:322: ADC0CF = (ADC0CF & 0xf8) | ganho;
      00063F 74 F8            [12] 2790 	mov	a,#0xf8
      000641 55 BC            [12] 2791 	anl	a,_ADC0CF
      000643 45 15            [12] 2792 	orl	a,_le_ADC0_PARM_2
      000645 F5 BC            [12] 2793 	mov	_ADC0CF,a
                           0005AE  2794 	C$p3main.c$323$1$61 ==.
                                   2795 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:323: AMX0SL = canal;
      000647 8F BB            [24] 2796 	mov	_AMX0SL,r7
                           0005B0  2797 	C$p3main.c$324$1$61 ==.
                                   2798 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:324: AD0BUSY = 1; // fire up AD conversion
      000649 D2 EC            [12] 2799 	setb	_AD0BUSY
                           0005B2  2800 	C$p3main.c$325$1$61 ==.
                                   2801 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:325: NOP();
      00064B 00               [12] 2802 	NOP	
                           0005B3  2803 	C$p3main.c$326$1$61 ==.
                                   2804 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:326: while(AD0BUSY); // wait untill conversion is finished
      00064C                       2805 00101$:
      00064C 20 EC FD         [24] 2806 	jb	_AD0BUSY,00101$
                           0005B6  2807 	C$p3main.c$328$1$61 ==.
                                   2808 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:328: return (ADC0H << 8 | ADC0L);
      00064F AF BF            [24] 2809 	mov	r7,_ADC0H
      000651 7E 00            [12] 2810 	mov	r6,#0x00
      000653 AC BE            [24] 2811 	mov	r4,_ADC0L
      000655 7D 00            [12] 2812 	mov	r5,#0x00
      000657 EC               [12] 2813 	mov	a,r4
      000658 4E               [12] 2814 	orl	a,r6
      000659 F5 82            [12] 2815 	mov	dpl,a
      00065B ED               [12] 2816 	mov	a,r5
      00065C 4F               [12] 2817 	orl	a,r7
      00065D F5 83            [12] 2818 	mov	dph,a
                           0005C6  2819 	C$p3main.c$330$1$61 ==.
                           0005C6  2820 	XG$le_ADC0$0$0 ==.
      00065F 22               [24] 2821 	ret
                                   2822 ;------------------------------------------------------------
                                   2823 ;Allocation info for local variables in function 'le_LM35'
                                   2824 ;------------------------------------------------------------
                                   2825 ;ladc                      Allocated to registers 
                                   2826 ;------------------------------------------------------------
                           0005C7  2827 	G$le_LM35$0$0 ==.
                           0005C7  2828 	C$p3main.c$333$1$61 ==.
                                   2829 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:333: void le_LM35() {
                                   2830 ;	-----------------------------------------
                                   2831 ;	 function le_LM35
                                   2832 ;	-----------------------------------------
      000660                       2833 _le_LM35:
                           0005C7  2834 	C$p3main.c$334$1$62 ==.
                                   2835 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:334: unsigned int ladc = le_ADC0(AIN0_0, G1);
      000660 75 15 00         [24] 2836 	mov	_le_ADC0_PARM_2,#0x00
      000663 75 82 00         [24] 2837 	mov	dpl,#0x00
      000666 12 06 3D         [24] 2838 	lcall	_le_ADC0
                           0005D0  2839 	C$p3main.c$335$1$62 ==.
                                   2840 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:335: printf_fast_f("Temperatura da placa peltier: %2.1f C\n", (ladc * 0.00059326171875 / 1) * 100);
      000669 12 0E D8         [24] 2841 	lcall	___uint2fs
      00066C AC 82            [24] 2842 	mov	r4,dpl
      00066E AD 83            [24] 2843 	mov	r5,dph
      000670 AE F0            [24] 2844 	mov	r6,b
      000672 FF               [12] 2845 	mov	r7,a
      000673 C0 04            [24] 2846 	push	ar4
      000675 C0 05            [24] 2847 	push	ar5
      000677 C0 06            [24] 2848 	push	ar6
      000679 C0 07            [24] 2849 	push	ar7
      00067B 90 85 1F         [24] 2850 	mov	dptr,#0x851f
      00067E 75 F0 1B         [24] 2851 	mov	b,#0x1b
      000681 74 3A            [12] 2852 	mov	a,#0x3a
      000683 12 0C 72         [24] 2853 	lcall	___fsmul
      000686 AC 82            [24] 2854 	mov	r4,dpl
      000688 AD 83            [24] 2855 	mov	r5,dph
      00068A AE F0            [24] 2856 	mov	r6,b
      00068C FF               [12] 2857 	mov	r7,a
      00068D E5 81            [12] 2858 	mov	a,sp
      00068F 24 FC            [12] 2859 	add	a,#0xfc
      000691 F5 81            [12] 2860 	mov	sp,a
      000693 C0 04            [24] 2861 	push	ar4
      000695 C0 05            [24] 2862 	push	ar5
      000697 C0 06            [24] 2863 	push	ar6
      000699 C0 07            [24] 2864 	push	ar7
      00069B 90 00 00         [24] 2865 	mov	dptr,#0x0000
      00069E 75 F0 C8         [24] 2866 	mov	b,#0xc8
      0006A1 74 42            [12] 2867 	mov	a,#0x42
      0006A3 12 0C 72         [24] 2868 	lcall	___fsmul
      0006A6 AC 82            [24] 2869 	mov	r4,dpl
      0006A8 AD 83            [24] 2870 	mov	r5,dph
      0006AA AE F0            [24] 2871 	mov	r6,b
      0006AC FF               [12] 2872 	mov	r7,a
      0006AD E5 81            [12] 2873 	mov	a,sp
      0006AF 24 FC            [12] 2874 	add	a,#0xfc
      0006B1 F5 81            [12] 2875 	mov	sp,a
      0006B3 C0 04            [24] 2876 	push	ar4
      0006B5 C0 05            [24] 2877 	push	ar5
      0006B7 C0 06            [24] 2878 	push	ar6
      0006B9 C0 07            [24] 2879 	push	ar7
      0006BB 74 DD            [12] 2880 	mov	a,#___str_18
      0006BD C0 E0            [24] 2881 	push	acc
      0006BF 74 11            [12] 2882 	mov	a,#(___str_18 >> 8)
      0006C1 C0 E0            [24] 2883 	push	acc
      0006C3 12 07 F1         [24] 2884 	lcall	_printf_fast_f
      0006C6 E5 81            [12] 2885 	mov	a,sp
      0006C8 24 FA            [12] 2886 	add	a,#0xfa
      0006CA F5 81            [12] 2887 	mov	sp,a
                           000633  2888 	C$p3main.c$336$1$62 ==.
                           000633  2889 	XG$le_LM35$0$0 ==.
      0006CC 22               [24] 2890 	ret
                                   2891 ;------------------------------------------------------------
                                   2892 ;Allocation info for local variables in function 'int_tc1'
                                   2893 ;------------------------------------------------------------
                           000634  2894 	G$int_tc1$0$0 ==.
                           000634  2895 	C$p3main.c$339$1$62 ==.
                                   2896 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:339: int int_tc1() interrupt 3 { // occurs every 2.62144 ms
                                   2897 ;	-----------------------------------------
                                   2898 ;	 function int_tc1
                                   2899 ;	-----------------------------------------
      0006CD                       2900 _int_tc1:
      0006CD C0 21            [24] 2901 	push	bits
      0006CF C0 E0            [24] 2902 	push	acc
      0006D1 C0 F0            [24] 2903 	push	b
      0006D3 C0 82            [24] 2904 	push	dpl
      0006D5 C0 83            [24] 2905 	push	dph
      0006D7 C0 07            [24] 2906 	push	(0+7)
      0006D9 C0 06            [24] 2907 	push	(0+6)
      0006DB C0 05            [24] 2908 	push	(0+5)
      0006DD C0 04            [24] 2909 	push	(0+4)
      0006DF C0 03            [24] 2910 	push	(0+3)
      0006E1 C0 02            [24] 2911 	push	(0+2)
      0006E3 C0 01            [24] 2912 	push	(0+1)
      0006E5 C0 00            [24] 2913 	push	(0+0)
      0006E7 C0 D0            [24] 2914 	push	psw
      0006E9 75 D0 00         [24] 2915 	mov	psw,#0x00
                           000653  2916 	C$p3main.c$340$1$63 ==.
                                   2917 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:340: TF1 = 0;
      0006EC C2 8F            [12] 2918 	clr	_TF1
                           000655  2919 	C$p3main.c$341$1$63 ==.
                                   2920 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:341: counter += 0.00262144;
      0006EE 74 77            [12] 2921 	mov	a,#0x77
      0006F0 C0 E0            [24] 2922 	push	acc
      0006F2 74 CC            [12] 2923 	mov	a,#0xcc
      0006F4 C0 E0            [24] 2924 	push	acc
      0006F6 74 2B            [12] 2925 	mov	a,#0x2b
      0006F8 C0 E0            [24] 2926 	push	acc
      0006FA 74 3B            [12] 2927 	mov	a,#0x3b
      0006FC C0 E0            [24] 2928 	push	acc
      0006FE 85 0A 82         [24] 2929 	mov	dpl,_counter
      000701 85 0B 83         [24] 2930 	mov	dph,(_counter + 1)
      000704 85 0C F0         [24] 2931 	mov	b,(_counter + 2)
      000707 E5 0D            [12] 2932 	mov	a,(_counter + 3)
      000709 12 0E 36         [24] 2933 	lcall	___fsadd
      00070C 85 82 0A         [24] 2934 	mov	_counter,dpl
      00070F 85 83 0B         [24] 2935 	mov	(_counter + 1),dph
      000712 85 F0 0C         [24] 2936 	mov	(_counter + 2),b
      000715 F5 0D            [12] 2937 	mov	(_counter + 3),a
      000717 E5 81            [12] 2938 	mov	a,sp
      000719 24 FC            [12] 2939 	add	a,#0xfc
      00071B F5 81            [12] 2940 	mov	sp,a
                           000684  2941 	C$p3main.c$342$1$63 ==.
                                   2942 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:342: if (counter > 1) IE1 = 1; // stop reading if pulse width > 1s
      00071D E4               [12] 2943 	clr	a
      00071E C0 E0            [24] 2944 	push	acc
      000720 C0 E0            [24] 2945 	push	acc
      000722 74 80            [12] 2946 	mov	a,#0x80
      000724 C0 E0            [24] 2947 	push	acc
      000726 74 3F            [12] 2948 	mov	a,#0x3f
      000728 C0 E0            [24] 2949 	push	acc
      00072A 85 0A 82         [24] 2950 	mov	dpl,_counter
      00072D 85 0B 83         [24] 2951 	mov	dph,(_counter + 1)
      000730 85 0C F0         [24] 2952 	mov	b,(_counter + 2)
      000733 E5 0D            [12] 2953 	mov	a,(_counter + 3)
      000735 12 0D B9         [24] 2954 	lcall	___fsgt
      000738 AF 82            [24] 2955 	mov	r7,dpl
      00073A E5 81            [12] 2956 	mov	a,sp
      00073C 24 FC            [12] 2957 	add	a,#0xfc
      00073E F5 81            [12] 2958 	mov	sp,a
      000740 EF               [12] 2959 	mov	a,r7
      000741 60 02            [24] 2960 	jz	00103$
      000743 D2 8B            [12] 2961 	setb	_IE1
      000745                       2962 00103$:
      000745 D0 D0            [24] 2963 	pop	psw
      000747 D0 00            [24] 2964 	pop	(0+0)
      000749 D0 01            [24] 2965 	pop	(0+1)
      00074B D0 02            [24] 2966 	pop	(0+2)
      00074D D0 03            [24] 2967 	pop	(0+3)
      00074F D0 04            [24] 2968 	pop	(0+4)
      000751 D0 05            [24] 2969 	pop	(0+5)
      000753 D0 06            [24] 2970 	pop	(0+6)
      000755 D0 07            [24] 2971 	pop	(0+7)
      000757 D0 83            [24] 2972 	pop	dph
      000759 D0 82            [24] 2973 	pop	dpl
      00075B D0 F0            [24] 2974 	pop	b
      00075D D0 E0            [24] 2975 	pop	acc
      00075F D0 21            [24] 2976 	pop	bits
                           0006C8  2977 	C$p3main.c$343$1$63 ==.
                           0006C8  2978 	XG$int_tc1$0$0 ==.
      000761 32               [24] 2979 	reti
                                   2980 ;------------------------------------------------------------
                                   2981 ;Allocation info for local variables in function 'le_pulso'
                                   2982 ;------------------------------------------------------------
                                   2983 ;t                         Allocated to registers 
                                   2984 ;------------------------------------------------------------
                           0006C9  2985 	G$le_pulso$0$0 ==.
                           0006C9  2986 	C$p3main.c$345$1$63 ==.
                                   2987 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:345: float le_pulso() {
                                   2988 ;	-----------------------------------------
                                   2989 ;	 function le_pulso
                                   2990 ;	-----------------------------------------
      000762                       2991 _le_pulso:
                           0006C9  2992 	C$p3main.c$348$1$64 ==.
                                   2993 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:348: while (P0_6);
      000762                       2994 00101$:
      000762 20 86 FD         [24] 2995 	jb	_P0_6,00101$
                           0006CC  2996 	C$p3main.c$350$1$64 ==.
                                   2997 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:350: counter = 0;
      000765 E4               [12] 2998 	clr	a
      000766 F5 0A            [12] 2999 	mov	_counter,a
      000768 F5 0B            [12] 3000 	mov	(_counter + 1),a
      00076A F5 0C            [12] 3001 	mov	(_counter + 2),a
      00076C F5 0D            [12] 3002 	mov	(_counter + 3),a
                           0006D5  3003 	C$p3main.c$351$1$64 ==.
                                   3004 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:351: IE1 = 0; // turn off external interrupt 1 flag
      00076E C2 8B            [12] 3005 	clr	_IE1
                           0006D7  3006 	C$p3main.c$352$1$64 ==.
                                   3007 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:352: TR1 = 1; // turn TC1 on, counting while INT1 pin is 1
      000770 D2 8E            [12] 3008 	setb	_TR1
                           0006D9  3009 	C$p3main.c$353$1$64 ==.
                                   3010 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:353: while(!IE1); // wait for 1->0 trasition to start counting 
      000772                       3011 00104$:
      000772 30 8B FD         [24] 3012 	jnb	_IE1,00104$
                           0006DC  3013 	C$p3main.c$354$1$64 ==.
                                   3014 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:354: TR1 = 0; // turn TC1 on
      000775 C2 8E            [12] 3015 	clr	_TR1
                           0006DE  3016 	C$p3main.c$355$1$64 ==.
                                   3017 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:355: TF1 = 0; // turn off TC1 overflow flag
      000777 C2 8F            [12] 3018 	clr	_TF1
                           0006E0  3019 	C$p3main.c$356$1$64 ==.
                                   3020 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:356: t = (unsigned int)TH1 * 256 + (unsigned int)TL1; // concatenates two 8 bit registers	
      000779 AF 8D            [24] 3021 	mov	r7,_TH1
      00077B 7E 00            [12] 3022 	mov	r6,#0x00
      00077D AC 8B            [24] 3023 	mov	r4,_TL1
      00077F 7D 00            [12] 3024 	mov	r5,#0x00
      000781 EC               [12] 3025 	mov	a,r4
      000782 2E               [12] 3026 	add	a,r6
      000783 F5 82            [12] 3027 	mov	dpl,a
      000785 ED               [12] 3028 	mov	a,r5
      000786 3F               [12] 3029 	addc	a,r7
      000787 F5 83            [12] 3030 	mov	dph,a
                           0006F0  3031 	C$p3main.c$357$1$64 ==.
                                   3032 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:357: TL1 = 0;
                                   3033 ;	1-genFromRTrack replaced	mov	_TL1,#0x00
      000789 8E 8B            [24] 3034 	mov	_TL1,r6
                           0006F2  3035 	C$p3main.c$358$1$64 ==.
                                   3036 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:358: TH1 = 0;
                                   3037 ;	1-genFromRTrack replaced	mov	_TH1,#0x00
      00078B 8E 8D            [24] 3038 	mov	_TH1,r6
                           0006F4  3039 	C$p3main.c$359$1$64 ==.
                                   3040 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:359: counter += (float)t / CLOCK; 
      00078D 12 0E D8         [24] 3041 	lcall	___uint2fs
      000790 AC 82            [24] 3042 	mov	r4,dpl
      000792 AD 83            [24] 3043 	mov	r5,dph
      000794 AE F0            [24] 3044 	mov	r6,b
      000796 FF               [12] 3045 	mov	r7,a
      000797 74 20            [12] 3046 	mov	a,#0x20
      000799 C0 E0            [24] 3047 	push	acc
      00079B 74 BC            [12] 3048 	mov	a,#0xbc
      00079D C0 E0            [24] 3049 	push	acc
      00079F 74 BE            [12] 3050 	mov	a,#0xbe
      0007A1 C0 E0            [24] 3051 	push	acc
      0007A3 74 4B            [12] 3052 	mov	a,#0x4b
      0007A5 C0 E0            [24] 3053 	push	acc
      0007A7 8C 82            [24] 3054 	mov	dpl,r4
      0007A9 8D 83            [24] 3055 	mov	dph,r5
      0007AB 8E F0            [24] 3056 	mov	b,r6
      0007AD EF               [12] 3057 	mov	a,r7
      0007AE 12 0F 4D         [24] 3058 	lcall	___fsdiv
      0007B1 AC 82            [24] 3059 	mov	r4,dpl
      0007B3 AD 83            [24] 3060 	mov	r5,dph
      0007B5 AE F0            [24] 3061 	mov	r6,b
      0007B7 FF               [12] 3062 	mov	r7,a
      0007B8 E5 81            [12] 3063 	mov	a,sp
      0007BA 24 FC            [12] 3064 	add	a,#0xfc
      0007BC F5 81            [12] 3065 	mov	sp,a
      0007BE C0 04            [24] 3066 	push	ar4
      0007C0 C0 05            [24] 3067 	push	ar5
      0007C2 C0 06            [24] 3068 	push	ar6
      0007C4 C0 07            [24] 3069 	push	ar7
      0007C6 85 0A 82         [24] 3070 	mov	dpl,_counter
      0007C9 85 0B 83         [24] 3071 	mov	dph,(_counter + 1)
      0007CC 85 0C F0         [24] 3072 	mov	b,(_counter + 2)
      0007CF E5 0D            [12] 3073 	mov	a,(_counter + 3)
      0007D1 12 0E 36         [24] 3074 	lcall	___fsadd
      0007D4 85 82 0A         [24] 3075 	mov	_counter,dpl
      0007D7 85 83 0B         [24] 3076 	mov	(_counter + 1),dph
      0007DA 85 F0 0C         [24] 3077 	mov	(_counter + 2),b
      0007DD F5 0D            [12] 3078 	mov	(_counter + 3),a
      0007DF E5 81            [12] 3079 	mov	a,sp
      0007E1 24 FC            [12] 3080 	add	a,#0xfc
      0007E3 F5 81            [12] 3081 	mov	sp,a
                           00074C  3082 	C$p3main.c$361$1$64 ==.
                                   3083 ;	Z:\9semestre\micap\micap-master\p3\p3main.c:361: return counter;
      0007E5 85 0A 82         [24] 3084 	mov	dpl,_counter
      0007E8 85 0B 83         [24] 3085 	mov	dph,(_counter + 1)
      0007EB 85 0C F0         [24] 3086 	mov	b,(_counter + 2)
      0007EE E5 0D            [12] 3087 	mov	a,(_counter + 3)
                           000757  3088 	C$p3main.c$362$1$64 ==.
                           000757  3089 	XG$le_pulso$0$0 ==.
      0007F0 22               [24] 3090 	ret
                                   3091 	.area CSEG    (CODE)
                                   3092 	.area CONST   (CODE)
                           000000  3093 Fp3main$__str_0$0$0 == .
      001043                       3094 ___str_0:
      001043 49 6E 69 63 69 61 6E  3095 	.ascii "Iniciando firmware."
             64 6F 20 66 69 72 6D
             77 61 72 65 2E
      001056 0A                    3096 	.db 0x0a
      001057 00                    3097 	.db 0x00
                           000015  3098 Fp3main$__str_1$0$0 == .
      001058                       3099 ___str_1:
      001058 54 65 6E 73 61 6F 20  3100 	.ascii "Tensao aplicada a placa peltier: %3.1fV"
             61 70 6C 69 63 61 64
             61 20 61 20 70 6C 61
             63 61 20 70 65 6C 74
             69 65 72 3A 20 25 33
             2E 31 66 56
      00107F 0A                    3101 	.db 0x0a
      001080 00                    3102 	.db 0x00
                           00003E  3103 Fp3main$__str_2$0$0 == .
      001081                       3104 ___str_2:
      001081 0A                    3105 	.db 0x0a
      001082 20 4D 45 4E 55 3A     3106 	.ascii " MENU:"
      001088 0A                    3107 	.db 0x0a
      001089 00                    3108 	.db 0x00
                           000047  3109 Fp3main$__str_3$0$0 == .
      00108A                       3110 ___str_3:
      00108A 61 3A 20 41 75 6D 65  3111 	.ascii "a: Aumenta RPM do motor."
             6E 74 61 20 52 50 4D
             20 64 6F 20 6D 6F 74
             6F 72 2E
      0010A2 0A                    3112 	.db 0x0a
      0010A3 00                    3113 	.db 0x00
                           000061  3114 Fp3main$__str_4$0$0 == .
      0010A4                       3115 ___str_4:
      0010A4 64 3A 20 44 69 6D 69  3116 	.ascii "d: Diminui RPM do motor."
             6E 75 69 20 52 50 4D
             20 64 6F 20 6D 6F 74
             6F 72 2E
      0010BC 0A                    3117 	.db 0x0a
      0010BD 00                    3118 	.db 0x00
                           00007B  3119 Fp3main$__str_5$0$0 == .
      0010BE                       3120 ___str_5:
      0010BE 70 3A 20 4C 69 67 61  3121 	.ascii "p: Liga/desliga fonte de energia placa peltier."
             2F 64 65 73 6C 69 67
             61 20 66 6F 6E 74 65
             20 64 65 20 65 6E 65
             72 67 69 61 20 70 6C
             61 63 61 20 70 65 6C
             74 69 65 72 2E
      0010ED 0A                    3122 	.db 0x0a
      0010EE 00                    3123 	.db 0x00
                           0000AC  3124 Fp3main$__str_6$0$0 == .
      0010EF                       3125 ___str_6:
      0010EF 72 3A 20 4D 65 64 65  3126 	.ascii "r: Mede rotacao do motor."
             20 72 6F 74 61 63 61
             6F 20 64 6F 20 6D 6F
             74 6F 72 2E
      001108 0A                    3127 	.db 0x0a
      001109 00                    3128 	.db 0x00
                           0000C7  3129 Fp3main$__str_7$0$0 == .
      00110A                       3130 ___str_7:
      00110A 31 3A 20 4D 65 64 65  3131 	.ascii "1: Mede temperatura do motor."
             20 74 65 6D 70 65 72
             61 74 75 72 61 20 64
             6F 20 6D 6F 74 6F 72
             2E
      001127 0A                    3132 	.db 0x0a
      001128 00                    3133 	.db 0x00
                           0000E6  3134 Fp3main$__str_8$0$0 == .
      001129                       3135 ___str_8:
      001129 32 3A 20 4D 65 64 65  3136 	.ascii "2: Mede tensao aplicada a placa peltier."
             20 74 65 6E 73 61 6F
             20 61 70 6C 69 63 61
             64 61 20 61 20 70 6C
             61 63 61 20 70 65 6C
             74 69 65 72 2E
      001151 0A                    3137 	.db 0x0a
      001152 00                    3138 	.db 0x00
                           000110  3139 Fp3main$__str_9$0$0 == .
      001153                       3140 ___str_9:
      001153 33 3A 20 54 65 73 74  3141 	.ascii "3: Testa RAM SPI."
             61 20 52 41 4D 20 53
             50 49 2E
      001164 0A                    3142 	.db 0x0a
      001165 00                    3143 	.db 0x00
                           000123  3144 Fp3main$__str_10$0$0 == .
      001166                       3145 ___str_10:
      001166 0A                    3146 	.db 0x0a
      001167 00                    3147 	.db 0x00
                           000125  3148 Fp3main$__str_11$0$0 == .
      001168                       3149 ___str_11:
      001168 20                    3150 	.ascii " "
      001169 00                    3151 	.db 0x00
                           000127  3152 Fp3main$__str_12$0$0 == .
      00116A                       3153 ___str_12:
      00116A 46 6F 6E 74 65 20 31  3154 	.ascii "Fonte 12V ligada."
             32 56 20 6C 69 67 61
             64 61 2E
      00117B 0A                    3155 	.db 0x0a
      00117C 00                    3156 	.db 0x00
                           00013A  3157 Fp3main$__str_13$0$0 == .
      00117D                       3158 ___str_13:
      00117D 46 6F 6E 74 65 20 31  3159 	.ascii "Fonte 12V desligada."
             32 56 20 64 65 73 6C
             69 67 61 64 61 2E
      001191 0A                    3160 	.db 0x0a
      001192 00                    3161 	.db 0x00
                           000150  3162 Fp3main$__str_14$0$0 == .
      001193                       3163 ___str_14:
      001193 52 6F 74 61 63 61 6F  3164 	.ascii "Rotacao do motor: %3.1f"
             20 64 6F 20 6D 6F 74
             6F 72 3A 20 25 33 2E
             31 66
      0011AA 0A                    3165 	.db 0x0a
      0011AB 00                    3166 	.db 0x00
                           000169  3167 Fp3main$__str_15$0$0 == .
      0011AC                       3168 ___str_15:
      0011AC 25 30 35 75 20        3169 	.ascii "%05u "
      0011B1 00                    3170 	.db 0x00
                           00016F  3171 Fp3main$__str_16$0$0 == .
      0011B2                       3172 ___str_16:
      0011B2 45 72 72 6F 20 65 6E  3173 	.ascii "Erro end. %05u"
             64 2E 20 25 30 35 75
      0011C0 0A                    3174 	.db 0x0a
      0011C1 00                    3175 	.db 0x00
                           00017F  3176 Fp3main$__str_17$0$0 == .
      0011C2                       3177 ___str_17:
      0011C2 46 69 6D 20 64 6F 20  3178 	.ascii "Fim do teste. RAM SPI ok!"
             74 65 73 74 65 2E 20
             52 41 4D 20 53 50 49
             20 6F 6B 21
      0011DB 0A                    3179 	.db 0x0a
      0011DC 00                    3180 	.db 0x00
                           00019A  3181 Fp3main$__str_18$0$0 == .
      0011DD                       3182 ___str_18:
      0011DD 54 65 6D 70 65 72 61  3183 	.ascii "Temperatura da placa peltier: %2.1f C"
             74 75 72 61 20 64 61
             20 70 6C 61 63 61 20
             70 65 6C 74 69 65 72
             3A 20 25 32 2E 31 66
             20 43
      001202 0A                    3184 	.db 0x0a
      001203 00                    3185 	.db 0x00
                                   3186 	.area XINIT   (CODE)
                                   3187 	.area CABS    (ABS,CODE)
